import('./qz-category.js').then(mod => {
    window.customElements.define('qz-category', mod.QuizCategory);
})
import('./qz-match.js').then(mod => {
    window.customElements.define('qz-match', mod.QuizMatch);
})
import('./qz-flipCard.js').then(mod => {
    window.customElements.define('qz-flipcard', mod.QuizFlipCard);
})
import('./qz-multi.js').then(mod => {
    window.customElements.define('qz-multi', mod.QuizMulti);
})
import('./qz-typer.js').then(mod => {
    window.customElements.define('qz-typer', mod.QuizTyper);
})
import('./qz-typer-new.js').then(mod => {
    window.customElements.define('qz-typer2', mod.QuizTyperNew);
})
import('./qz-practice.js').then(mod => {
    window.customElements.define('qz-practice', mod.QuizPractice);
})
import('./qz-quiz.js').then(mod => {
    window.customElements.define('qz-quiz', mod.Quiz);
})
