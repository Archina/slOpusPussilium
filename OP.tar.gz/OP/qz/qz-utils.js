export const SolvedEvent = () => new CustomEvent('qz-solved', {bubbles: true});
export const FailedEvent = () => new CustomEvent('qz-failed', {bubbles: true});
export const ResetEvent = () => new CustomEvent('qz-reset', {bubbles: false});


// This module makes notifications available for sending.
export const NotifyModule = (() => {
    
    const NotifyState = {
        Granted: 'granted',
        Denied: 'denied',
        Unavailable: 'unavailable',
    }

    let state = NotifyState.Unavailable;

    if (!("Notification" in window)) {
        state = NotifyState.Unavailable;
       } else if (Notification.permission === "granted") {
        state = NotifyState.Granted;
       } else if (Notification.permission !== 'denied') {
        Notification.requestPermission().then(function(permission) {
            if (permission === "granted") {
                state = NotifyState.Granted;
            } else {
                state = NotifyState.Denied;
            }
        });
       }
  
    function sendNotifcation(message) {
        new Notification("QzQuizes from Squidlet.design", { body: message });
    }

    return {
        /** @param {string} message - The due date of the task as a number. */
        sendNotifcation: function(message) {
            if(state == NotifyState.Granted){
                sendNotifcation(message);
            }
        },
        canNotify: function() {
            return state == NotifyState.Granted;
        }
    };
})();

// This module should manage timers and send them - check once every 5 minutes, no need to check more often.

// If a quiz is expiring soon, forward a practice round and send a notification
export const ReminderModule = (() => {
    /**
     * @typedef {Object} Reminder
     * @property {number} dueDate - The due date of the task as a number.
     * @property {string} qz-id - The identifier for the task as a string.
     */

    /**
     * @type {Reminder[]}
     */
    let queued_reminders = [];
    
    setInterval(() => {
        let currentTime = Date.now();
        const considering = queued_reminders.filter(r => r.dueDate <= currentTime);
        queued_reminders = queued_reminders.filter(r => r.dueDate > currentTime);

        if(considering.length > 0) {
            NotifyModule.sendNotifcation(`${considering.length} Quizes are ready for review...`);
        }
    }, 5 * 60 * 1000);

    return {
        
        /**
         * @param {Reminder} reminder
         * */
        enque: function(reminder) {
            queued_reminders.push(reminder);
        },
    };
})();