import { FailedEvent, SolvedEvent } from './qz-utils.js';
import { shuffle } from './shuffle.js';

export class QuizMulti extends HTMLElement {
    constructor(){
        super();
        
        this.initialized = false;

        this.fauxAnswers = [];
        this.correctAnswers = [];
        this.question = null;
        
        this.maxCorrect = 1;
        this.maxOptions = 4;

        this.correct = undefined;
    }
    
    connectedCallback(){
        const maxCorrect = parseInt(this.getAttribute('max-correct'));
        if(!Number.isNaN(maxCorrect)){ this.maxCorrect = maxCorrect; }
        
        const maxOptions = parseInt(this.getAttribute('max-options'));
        if(!Number.isNaN(maxOptions)){ this.maxOptions = maxOptions; }
        
        this.addEventListener('click', event => {
            if(event.target == this.querySelector('button')) {
                let userAnswers = Array.from(this.querySelectorAll('input[type="checkbox"]')).map(cb => cb.checked);
                this.correct = true;
                this.keys.forEach((val, idx) => {
                    if(val !== userAnswers[idx]) {this.correct = false}
                })
                if(!this.correct){
                    this.dispatchEvent(FailedEvent());
                    this.generateAnswer();
                } else {
                    this.dispatchEvent(SolvedEvent());
                }
                // alert(`Your answers were ${this.correct}!`);
                this.render();
            }
        })

        this.addEventListener('keyup', event => {
            if(event.key === 'Backspace'){
                this.correct = false;
                this.generateAnswer();
                this.render();
            } else if(event.key === '?'){
                this.correct = true;
                this.render();
            }
        })
        
        if(!this.initialized) {
            this.initialized = true;
            this.fauxAnswers = [];
            this.correctAnswers = [];
            Array.from(this.querySelectorAll('qz-answer')).forEach((answer) => {
                const content = answer.innerHTML;
                if(answer.hasAttribute('qz-correct')) {
                    this.correctAnswers.push(content);
                } else {
                    this.fauxAnswers.push(content);
                }
                answer.remove();
            });
            this.question = this.querySelector('qz-question')?.innerHTML;
        }

        this.addEventListener('qz-reset', e => {
            this.correct = undefined;
            this.generateAnswer();
            this.render();
        });

        this.generateAnswer();
        this.render();
    }

    generateAnswer(){
        this.answers = shuffle([
            ...shuffle(this.correctAnswers.map(ca => ({content: ca, correct: true}))).slice(0, this.maxCorrect),
            ...shuffle(this.fauxAnswers.map(fa => ({content: fa, correct: false}))).slice(0, this.maxOptions - this.maxCorrect)
        ]);
        this.keys = this.answers.map(({correct}) => correct);
    }

    render(){
        function renderQuestion(question){
            return `${question ? `<div class="quizard-question">${question}</div>` : ''}`
        }

        function renderQuiz(question, answers) {
            return `
                ${renderQuestion(question)}
                <div class="quizard-answers">
                ${answers.map(({content}) => `<label class="framed"><input type="checkbox"><p>${content}</p></label>`).join('')}
                </div>
                <button>Evaluate</button>
            `;
        }

        function renderSuccess(question, answers){
            // return `<div class="correct framed">Correct</div>`
            return `
                ${renderQuestion(question)}
                <div class="quizard-answers" tabIndex="0">
                ${answers.filter(({correct}) => correct).map(({content}) => `<label class="framed correct"><input type="checkbox" checked disabled><p>${content}</p></label>`).join('')}
                </div>
            `;
        }

        //${JSON.stringify(this.keys)}
        const template = this.correct ? `${renderSuccess(this.question, this.correctAnswers.map(ca => ({content: ca, correct: true})))}` : `${renderQuiz(this.question, this.answers)}`; 

        const previouslyFalse = this.correct !== undefined && !this.correct;
        this.innerHTML = `<div class="quizard-container ${previouslyFalse ? ' incorrect': ''}">${template}</div>`;
        // this.shadowRoot.innerHTML = template

        // this.textContent = `Your quiz could be here... Found ${this.fauxAnswers.length + this.correctAnswers.length}`;
    }
}
