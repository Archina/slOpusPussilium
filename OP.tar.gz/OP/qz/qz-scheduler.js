export function createCard(overrides = {}) {
  return {
    id: overrides.id ?? crypto.randomUUID(),
    interval: 1,
    ease: 2.5,
    stability: 1,
    difficulty: 0.5,
    streak: 0,
    failures: 0,
    successes: 0,
    dueDate: Date.now(),
    lastReviewed: Date.now(),
    elapsed: 0,
    ...overrides,
  };
}

export function review(card, rating) {
  const now = Date.now();
  const elapsed = Math.max(0, (now - card.lastReviewed) / (1000 * 60));

  let interval, ease, stability, difficulty;

  switch (rating) {
    case "again":
      interval = Math.max(1, card.interval * 0.5);
      ease = Math.max(1.3, card.ease - 0.2);
      stability = Math.max(1, card.stability * 0.5);
      difficulty = Math.min(1, card.difficulty + 0.05);
      card.streak = 0;
      card.failures += 1;
      break;
    case "hard":
      interval = Math.max(1, card.interval * 1.2);
      ease = Math.max(1.3, card.ease - 0.15);
      stability = Math.max(
        1,
        card.stability * (1 + 0.1 * (1 - card.difficulty)),
      );
      difficulty = Math.min(1, card.difficulty + 0.02);
      card.streak += 1;
      break;
    case "good":
      interval = Math.max(1, card.interval * card.ease);
      ease = card.ease;
      stability = Math.max(
        1,
        card.stability * (1 + 0.5 * (1 - card.difficulty)),
      );
      difficulty = Math.max(0, card.difficulty - 0.02);
      card.streak += 1;
      card.successes += 1;
      break;
    case "easy":
      interval = Math.max(1, card.interval * card.ease * 1.3);
      ease = Math.min(3.0, card.ease + 0.15);
      stability = Math.max(
        1,
        card.stability * (1 + 1.0 * (1 - card.difficulty)),
      );
      difficulty = Math.max(0, card.difficulty - 0.05);
      card.streak += 1;
      card.successes += 1;
      break;
    default:
      throw new Error(`Unknown rating: ${rating}`);
  }

  interval = Math.max(1, interval);
  ease = Math.max(1.3, ease);
  stability = Math.max(1, stability);
  difficulty = Math.max(0, Math.min(1, difficulty));

  if (Number.isNaN(interval)) interval = 1;
  if (Number.isNaN(ease)) ease = 2.5;
  if (Number.isNaN(stability)) stability = 1;
  if (Number.isNaN(difficulty)) difficulty = 0.5;

  card.interval = interval;
  card.ease = ease;
  card.stability = stability;
  card.difficulty = difficulty;
  card.elapsed = elapsed;
  card.lastReviewed = now;
  card.dueDate = now + interval * 60 * 1000;

  return card;
}

export function recallProbability(elapsed, stability) {
  if (stability <= 0) return 0;
  return Math.exp(-elapsed / stability);
}

export function isDue(card, now = Date.now()) {
  return card.dueDate <= now;
}

export function getMastery(card) {
  return Math.min(
    1,
    card.successes / Math.max(1, card.successes + card.failures),
  );
}

export function getRecallProb(card, now = Date.now()) {
  const elapsed = Math.max(0, (now - card.lastReviewed) / (1000 * 60));
  return recallProbability(elapsed, card.stability);
}

export function getPriority(card, now = Date.now()) {
  if (card.dueDate <= now) return 0;
  return card.dueDate - now;
}

export const Ratings = Object.freeze({
  Again: "again",
  Hard: "hard",
  Good: "good",
  Easy: "easy",
});

export const BUCKETS = [
  { min: -Infinity, max: 0, label: "ready", gray: true },
  { min: 0, max: 20, label: "<20m" },
  { min: 20, max: 60, label: "<1h" },
  { min: 60, max: 1440, label: "<1d" },
  { min: 1440, max: 10080, label: "<1w" },
  { min: 10080, max: 525600, label: "<1y" },
  { min: 525600, max: Infinity, label: ">1y" },
];

export function intervalColor(minutes) {
  if (minutes <= 0) return "#666";

  const keypoints = [
    { logMin: 4.32, hue: 0, sat: 80, light: 50 },     // 20 min → red
    { logMin: 5.32, hue: 40, sat: 80, light: 50 },    // 40 min → orange
    { logMin: 10.49, hue: 120, sat: 80, light: 50 },  // 1 day → green
    { logMin: 13.30, hue: 180, sat: 75, light: 52 },  // 1 week → cyan
    { logMin: 19.00, hue: 240, sat: 70, light: 55 },  // 1 year → blue
    { logMin: 22.30, hue: 300, sat: 65, light: 55 },  // 10 years → purple
  ];

  const logMin = Math.log2(Math.max(minutes, 1));

  if (logMin <= keypoints[0].logMin) return `hsl(${keypoints[0].hue}, ${keypoints[0].sat}%, ${keypoints[0].light}%)`;
  if (logMin >= keypoints[keypoints.length - 1].logMin) return `hsl(${keypoints[keypoints.length - 1].hue}, ${keypoints[keypoints.length - 1].sat}%, ${keypoints[keypoints.length - 1].light}%)`;

  for (let i = 0; i < keypoints.length - 1; i++) {
    const a = keypoints[i];
    const b = keypoints[i + 1];
    if (logMin >= a.logMin && logMin <= b.logMin) {
      const t = (logMin - a.logMin) / (b.logMin - a.logMin);
      const hue = a.hue + t * (b.hue - a.hue);
      const sat = a.sat + t * (b.sat - a.sat);
      const light = a.light + t * (b.light - a.light);
      return `hsl(${hue.toFixed(0)}, ${sat.toFixed(0)}%, ${light.toFixed(0)}%)`;
    }
  }

  return "hsl(300, 65%, 55%)";
}

export function buildSegments(lockedDueDates, unlockedCount, total) {
  if (total === 0) return "";
  const counts = new Array(BUCKETS.length).fill(0);
  lockedDueDates.forEach((dueDate) => {
    const min = (dueDate - Date.now()) / 60000;
    const idx = BUCKETS.findIndex((b) => min > b.min && min <= b.max);
    if (idx !== -1) counts[idx]++;
  });
  counts[0] = unlockedCount;

  const grayBucket = BUCKETS.findIndex((b) => b.gray);
  const reordered = [
    ...BUCKETS.slice(0, grayBucket),
    ...BUCKETS.slice(grayBucket + 1),
    BUCKETS[grayBucket],
  ];

  return reordered
    .map((b) => {
      const idx = BUCKETS.indexOf(b);
      const cnt = counts[idx];
      if (cnt === 0) return "";
      const w = ((cnt / total) * 100).toFixed(1);
      const mid =
        b.min === -Infinity
          ? 0
          : b.max === Infinity
            ? 1e6
            : (b.min + b.max) / 2;
      const color = b.gray ? "#666" : intervalColor(mid);
      return `<div style="width:${w}%;background:${color}" title="${b.label}: ${cnt}"></div>`;
    })
    .filter(Boolean)
    .join("");
}
