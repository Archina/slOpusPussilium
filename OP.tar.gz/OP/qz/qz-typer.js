import { FailedEvent, SolvedEvent } from './qz-utils.js';

export class QuizTyper extends HTMLElement {
    constructor(){
        super();

        /** @private @type {string | ''} */
        this.word = '';
        /** @private @type {number | -1} */
        this.index = -1;

        /** @private @type {boolean} */
        this.active = false;

        /** @private @type {boolean|undefined} */
        this.correct = undefined;
    }
    
    connectedCallback(){
        // const difficulty = parseFloat(this.getAttribute('difficulty'));
        // if(!Number.isNaN(difficulty)){ this.maxCorrect = difficulty; }
        this.word = this.innerHTML;

        this.addEventListener('qz-reset', _e => {
            this.correct = undefined;
            this.index = -1;
            this.classList.remove('qz-type-error');
            this.render();
        });

        if(this.isDesktop()){

            this.setAttribute('tabIndex', 0);
            
            this.addEventListener('focus', event => {
                this.active = true;
            })
    
            this.addEventListener('blur', event => {
                this.active = false;
                // Here we could wrap up if we wanted...
            })
            
            this.addEventListener('keydown', event => {
                if(this.active) {
                    if(!this.correct){
                        if(event.key.length === 1 && (event.key === "?" || this.word.toLocaleLowerCase().indexOf(event.key.toLocaleLowerCase()) >= 0)) {
                            event.preventDefault();
                            event.stopPropagation();
                            if(event.key === "?" || this.word[this.index+1].toLocaleLowerCase().charCodeAt() === event.key.toLocaleLowerCase().charCodeAt()){
                                this.index++;
                                this.classList.remove("qz-type-error");
                                // Do green animation
                                if(this.index + 1 === this.word.length){
                                    this.correct = true;
                                    this.dispatchEvent(SolvedEvent());
                                }
                                this.render();
                            }
                        } else {    
                            // Do error animation in red
                            this.classList.remove("qz-type-error");
                            // Reflow
                            void this.offsetWidth;
                            this.classList.add("qz-type-error");
                        }
                    }else if(event.key === "Enter") {
                        // Focus next element
                        this.classList.remove("qz-type-error");
                        this.blur()
                    } else if(event.key === "Backspace") {
                        // Reset component
                        this.classList.remove("qz-type-error");
                        this.correct = false;
                        this.dispatchEvent(FailedEvent());
                        this.index = -1;
                        this.render();
                    }
                }
            })
        }
        
        if(!this.initialized) {
            this.initialized = true;
        }

        this.render();
    }

    isDesktop(){
        return true;
    }

    render(){
        this.innerHTML = this._renderQuiz();
    }

    _renderQuiz() {
        if(this.isDesktop()){
            return `<span class="quizard-typer">${[...this.word].map((c, i) => i < this.index+1 ?
                (this.index === i && !this.correct ? `<span style="color:greenyellow;">${c}</span>` : c) :
                '_'
            ).join('')}</span>`;
        } else {
            return this.word;
        }
    }
}
