import { shuffle } from './shuffle.js';
import { FailedEvent, SolvedEvent } from './qz-utils.js';

// qz-front
// qz-back

export class QuizFlipCard extends HTMLElement{
    front = null;
    back = null;

    userInput = '';

    stage = 0;
    
    constructor() {
        super();
        this.front = this.querySelector('qz-front');
        this.back = this.querySelector('qz-back');

        this.render();
    }

    connectedCallback(){
        this.addEventListener('qz-reset', e => {
            if(this.stage = 2){
                this.stage = 0;
                this.render();
            }
        });
    }

    promptFront(){
        this.innerHTML = 
            `<div class='quizard-flipcard quizard-container quizard-row-gap'><div class="framed">${this.front?.innerHTML}</div><textarea class="framed" rows="5" placeholder="Write your guesses in here..."></textarea><button>Reveal Answer</button></div>`;

        this.querySelector('button').addEventListener('click', () => {
            if(this.userInput === this.back?.innerText){
                this.stage = 2;
                this.dispatchEvent(SolvedEvent());
            } else {
                this.stage = 1;
            }

            this.render();
        });
        this.querySelector('input,textarea').addEventListener('change', event => {
            this.userInput = event.target.value;
        });
    }

    revealBack(){
        this.innerHTML = 
            `<div class='quizard-flipcard quizard-container quizard-row-gap'><div class="framed">${this.front?.innerHTML}</div><div class="framed" style="white-space: break-spaces; word-wrap: normal;">${this.userInput}</div><div class="framed">${this.back?.innerHTML}</div><div class="buttons"><button>Retry</button><button>Correct</button></div></div>`;
        let buttons = this.querySelectorAll('button');
        buttons[0].addEventListener('click', () => {
            this.stage = 0;
            this.dispatchEvent(FailedEvent());
            this.render();
        });
        buttons[1].addEventListener('click', () => {
            this.stage = 2;
            this.dispatchEvent(SolvedEvent());
            this.render();
        });
    }

    finish(){
        this.innerHTML = 
            `<div class='quizard-flipcard quizard-container quizard-row-gap'><div class="framed">${this.front?.innerHTML}</div><div class="framed">${this.back?.innerHTML}</div></div>`;
    }

    render(){
        switch(this.stage){
            case 0:
                this.promptFront();
                break;
            case 1:
                this.revealBack();
                break;
            default: this.finish();
        }
    }
}
