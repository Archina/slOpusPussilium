import { ReminderModule, ResetEvent } from "./qz-utils.js";
import { Quiz } from "./qz-quiz.js";
import { createCard, review, getPriority, getRecallProb } from "./qz-scheduler.js";

export class QuizPractice extends HTMLElement {
  constructor() {
    super();
    this.cardId = this.getAttribute("qz-level-id") ?? crypto.randomUUID();
    this.card = this.load();
    this.timer = null;
  }

  load() {
    try {
      const stored = JSON.parse(localStorage.getItem(this.cardId));
      if (stored && stored.interval !== undefined) {
        return { ...createCard({ id: this.cardId }), ...stored };
      }
    } catch {
      /* corrupted state — fall back to fresh card */
    }
    return createCard({ id: this.cardId });
  }

  save() {
    localStorage.setItem(this.cardId, JSON.stringify(this.card));
  }

  connectedCallback() {
    this.addEventListener("qz-solved", (e) => {
      if (!(this.parentElement instanceof Quiz)) {
        e.stopImmediatePropagation();
      }
      this.createFloater(e.target);
      review(this.card, "good");
      this.save();
      this.syncTimer();
      this.render();
    });

    this.addEventListener("qz-failed", (e) => {
      if (!(this.parentElement instanceof Quiz)) {
        e.stopImmediatePropagation();
      }
      review(this.card, "again");
      this.save();
      this.syncTimer();
      this.render();
    });

    if (this.card.dueDate > Date.now()) {
      this.setTimer();
    }
    this.render();
  }

  isLocked() {
    return this.card.dueDate > Date.now();
  }

  getPriority() {
    return getPriority(this.card);
  }

  getDueDate() {
    return this.card.dueDate;
  }

  getDifficulty() {
    return this.card.difficulty;
  }

  createFloater(e) {
    const { left, top, width, height } = e.getBoundingClientRect();
    const el = document.createElement("div");
    el.innerText = "\uD83E\uDD90";
    el.style.cssText = `
      position: fixed; top: ${top + Math.random() * height}px;
      left: ${left + Math.random() * width}px; pointer-events: none;
    `;
    el.classList.add("qz-wiggler", "qz-float");
    document.body.appendChild(el);
    el.addEventListener("animationend", () => el.remove());
  }

  setTimer() {
    this.clearTimer();
    const eta = this.card.dueDate - Date.now();
    if (eta <= 0) return;
    this.timer = setTimeout(() => {
      ReminderModule.enque({
        "qz-id": this.cardId,
        dueDate: this.card.dueDate,
      });
      this.childNodes.forEach((c) => c.dispatchEvent(ResetEvent()));
      this.render();
    }, eta);
  }

  clearTimer() {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }

  syncTimer() {
    if (this.card.dueDate > Date.now()) {
      this.setTimer();
    } else {
      this.clearTimer();
    }
  }

  render() {
    const locked = this.card.dueDate > Date.now();
    const recall = getRecallProb(this.card);
    const composite = (1 - this.card.difficulty) * recall;
    const level = Math.min(Math.round(composite * 8), 8);

    const existingOverlay = this.querySelector(":scope > .qz-overlay");
    if (existingOverlay) existingOverlay.remove();

    const existingScore = this.querySelector(":scope > .qz-score");
    if (existingScore) existingScore.remove();

    const stepSize = 4;
    let score =
      "🪼".repeat(Math.floor(level / stepSize)) +
      "🦐".repeat(level % stepSize);
    score = `<span style="font-size:2em">${score}</span>`;

    this.insertAdjacentHTML(
      "beforeend",
      `<div class="qz-score" title="Difficulty: ${(this.card.difficulty * 100).toFixed(0)}% | Recall: ${(recall * 100).toFixed(0)}%" style="position:absolute;top:0;right:1.5rem;z-index:100">${score}</div>`,
    );

    if (locked) {
      this.insertAdjacentHTML(
        "beforeend",
        `<div class="qz-overlay" style="position:absolute;inset:0;background:rgba(0,0,0,0.67);z-index:10;display:flex;justify-content:center;align-items:center"><span>Review at ${new Date(this.card.dueDate).toLocaleTimeString()}</span></div>`,
      );
    }
  }
}
