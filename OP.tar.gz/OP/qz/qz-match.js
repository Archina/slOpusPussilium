import { shuffle } from './shuffle.js';

export class QuizMatch extends HTMLElement{
    constructor() {
        super();
    }
}
