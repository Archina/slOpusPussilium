import { shuffle } from "./shuffle.js";

export function pickRandom(array, countOrNull){
    return countOrNull !== null ? shuffle(array).slice(0, countOrNull) : shuffle(array);
}