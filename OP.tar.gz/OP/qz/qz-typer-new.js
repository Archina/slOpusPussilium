import { FailedEvent, SolvedEvent } from './qz-utils.js';

export class QuizTyperNew extends HTMLElement {
    constructor(){
        super();

        /** @private @type {string | ''} */
        this.word = '';
        /** @private @type {number | -1} */
        this.index = -1;

        /** @private @type {boolean} */
        this.active = false;

        /** @private @type {boolean|undefined} */
        this.correct = undefined;
    }
    
    connectedCallback(){
        // const difficulty = parseFloat(this.getAttribute('difficulty'));
        // if(!Number.isNaN(difficulty)){ this.maxCorrect = difficulty; }
        this.word = this.innerHTML;

        this.addEventListener('qz-reset', _e => {
            this.correct = undefined;
            this.index = -1;
            this.classList.remove('qz-type-error');
            this.render();
        });
        // this.setAttribute('tabIndex', 0);

        this.addEventListener('click', event => {
            const input = this.querySelector('input');
            if(!input.focused) {
                input.focus();
            } else {
                input.blur();
            }
        })
        
        this.addEventListener('keydown', event => {
            if(this.active) {
                if(!this.correct){
                    if(event.key.length === 1 && (event.key === "?" || this.word.toLocaleLowerCase().indexOf(event.key.toLocaleLowerCase()) >= 0)) {
                        event.preventDefault();
                        event.stopPropagation();
                        if(event.key === "?" || this.word[this.index+1].toLocaleLowerCase().charCodeAt() === event.key.toLocaleLowerCase().charCodeAt()){
                            this.index++;
                            // Do green animation
                            if(this.index + 1 === this.word.length){
                                this.correct = true;
                                this.dispatchEvent(SolvedEvent());
                            }
                            this.render();
                        } else {
                            // Do error animation in red
                        }
                    }
                }else if(event.key === "Enter") {
                        // Focus next element
                        this.blur()
                } else if(event.key === "Backspace") {
                    // Reset component
                    this.correct = false;
                    this.dispatchEvent(FailedEvent());
                    this.index = -1;
                    this.render();
                }
            }
        })
        
        if(!this.initialized) {
            this.initialized = true;
        }

        this.render();
    }

    render(){
        this.innerHTML = this._renderQuiz();

        let input = this.querySelector('input');
        input.addEventListener('focus', _event => {
            this.active = true;
            this.classList.add("active");
        });
        input.addEventListener('blur', _event => {
            this.active = false;
            this.classList.remove("active");
        });
        input.addEventListener('keypress', event => {
            if(this.active) {
                if(!this.correct){
                    if(event.key.length === 1 && (event.key === "?" || this.word.toLocaleLowerCase().indexOf(event.key.toLocaleLowerCase()) >= 0)) {
                        event.preventDefault();
                        event.stopPropagation();
                        if(event.key === "?" || this.word[this.index+1].toLocaleLowerCase().charCodeAt() === event.key.toLocaleLowerCase().charCodeAt()){
                            this.index++;
                            // Do green animation
                            if(this.index + 1 === this.word.length){
                                this.correct = true;
                                this.dispatchEvent(SolvedEvent());
                            }
                            this.render();
                        }
                    } else {
                        // Do error animation in red
                        this.classList.remove("qz-type-error");
                        // Reflow
                        void this.offsetWidth;
                        this.classList.add("qz-type-error");
                    }
                }else if(event.key === "Enter") {
                    // Focus next element
                    this.blur()
                } else if(event.key === "Backspace") {
                    // Reset component
                    this.correct = false;
                    this.dispatchEvent(FailedEvent());
                    this.index = -1;
                    this.render();
                } 
                input.value = "";
            }
        });

        if(this.active){
            input.focus();
        }
        input.addEventListener('focus', _event => {
            this.active = true;
            this.classList.add("active");
        });

        input.addEventListener('blur', _event => {
            this.active = false;
            this.classList.remove("active");
        });
        input.addEventListener('keypress', event => {
            if(this.active) {
                if(!this.correct){
                    if(event.key.length === 1 && (event.key === "?" || this.word.toLocaleLowerCase().indexOf(event.key.toLocaleLowerCase()) >= 0)) {
                        event.preventDefault();
                        event.stopPropagation();
                        if(event.key === "?" || this.word[this.index+1].toLocaleLowerCase().charCodeAt() === event.key.toLocaleLowerCase().charCodeAt()){
                            this.index++;
                            // Do green animation
                            if(this.index + 1 === this.word.length){
                                this.correct = true;
                                this.dispatchEvent(SolvedEvent());
                            }
                            this.render();
                        }
                    } else {
                        // Do error animation in red
                        this.classList.remove("qz-type-error");
                        // Reflow
                        void this.offsetWidth;
                        this.classList.add("qz-type-error");
                    }
                }else if(event.key === "Enter") {
                    // Focus next element
                    this.blur()
                } else if(event.key === "Backspace") {
                    // Reset component
                    this.correct = false;
                    this.dispatchEvent(FailedEvent());
                    this.index = -1;
                    this.render();
                } 
                input.value = "";
            }
        });
    }

    _renderQuiz() {
        return `<span class="quizard-typer">${[...this.word].map((c, i) => i < this.index+1 ?
            (this.index === i && !this.correct ? `<span style="color:greenyellow;">${c}</span>` : c) :
            '_'
        ).join('')}<input tabIndex="0" type="text" style="background-color: red; pointer-events:none; position: relative; left: 0; right:0; width: 2px;" autocapitalize="none" autocomplete="off" autocorrect="off" spellcheck="false" value=""/></span>`;
    }
}
