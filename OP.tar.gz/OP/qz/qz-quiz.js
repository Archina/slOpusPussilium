import { shuffle } from './shuffle.js';
import { BUCKETS, intervalColor, buildSegments } from './qz-scheduler.js';

export { BUCKETS, intervalColor, buildSegments };

export class Quiz extends HTMLElement {
  constructor() {
    super();
    setTimeout(() => this.shuffle(), 50);
  }

  connectedCallback() {
    this.addEventListener('qz-solved', e => {
      e.stopImmediatePropagation();
      this.shuffle();
    });
    this.addEventListener('qz-failed', e => {
      e.stopImmediatePropagation();
      this.shuffle();
    });
  }

  shuffle() {
    let practices = shuffle([...this.querySelectorAll("qz-practice")]);

    practices.forEach(ele => ele.style.display = 'none');

    let unlocked_ps = practices.filter(x => !x.isLocked()).toSorted((a, b) => a.getPriority() - b.getPriority());
    let locked_ps = practices.filter(x => x.isLocked()).toSorted((a, b) => a.getDueDate() - b.getDueDate());

    let practice = null;
    if (unlocked_ps.length > 0) {
      practice = unlocked_ps[0];
    } else if (locked_ps.length > 0) {
      practice = locked_ps[0];
    } else {
      console.warn("No practices found whatsoever...");
    }

    const aboutElement = this.querySelector('.about') ?? this.appendChild((() => { let ele = document.createElement('div'); ele.classList.add('about'); return ele })());

    const statisticsElement = this.querySelector('.statistics') ?? (() => {
      let ele = document.createElement('div');
      ele.classList.add('statistics');
      this.prepend(ele, this.childNodes[0]);
      return ele;
    })();

    const total = practices.length;

    function intervalColor(minutes) {
      if (minutes <= 0) return '#666';
      const logMin = Math.log2(minutes);
      const t = (logMin - 2.32) / (10.49 - 2.32);
      if (t <= 0) return 'hsl(0, 80%, 50%)';
      if (t >= 2) return 'hsl(240, 70%, 55%)';
      if (t <= 1) return `hsl(${t * 120}, 80%, 50%)`;
      return `hsl(${120 + (t - 1) * 120}, 70%, 55%)`;
    }

    if (total > 0) {
      const inner = buildSegments(locked_ps.map(p => p.getDueDate()), unlocked_ps.length, total);
      statisticsElement.innerHTML = `<div style="display:flex;width:200px;height:20px;border-radius:4px;overflow:hidden">${inner}</div>`;
      aboutElement.innerText = `${unlocked_ps.length} ready · ${locked_ps.length} scheduled`;
    }

    if (practice) {
      practice.style.display = '';
      practice.children[0]?.dispatchEvent(new CustomEvent('qz-reset', { bubbles: false }));
    }
  }
}
