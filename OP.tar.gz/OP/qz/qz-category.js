import { shuffle } from './shuffle.js';
import { pickRandom } from './pick.js';
import { playAnimation } from './playAnimation.js';
import { FailedEvent, SolvedEvent } from './qz-utils.js';

export class QuizCategory extends HTMLElement{
    constructor(){
        super();
        
        this.initialized = false;

        // Complete Pool
        this.answersByCategories = [
            { answers: [], title: null, color: null, pick: null }, // answerWithoutCategories
        ];
        this.question = null;

        // Quiz Prep
        this.answers = []
        this.answerIndexToCategoryIndex = []
        this.userIndexToCategoryIndex = []

        this.currentlySelectedCategory = 0;
        this.maxCategories = 5;

        // Categories shown this round (subset when more than maxCategories)
        this.activeCategories = [];
        // False positives (answers that belong to no displayed category);
        // null = include all of them
        this.maxDistractors = null;

        // Quiz Score
        this.correct = undefined;
    }
    
    connectedCallback(){
        const maxCategories = parseInt(this.getAttribute('max-categories'));
        if(!Number.isNaN(maxCategories)){ this.maxCategories = Math.max(1, maxCategories); }

        const maxDistractors = parseInt(this.getAttribute('max-distractors'));
        if(!Number.isNaN(maxDistractors)){ this.maxDistractors = Math.max(0, maxDistractors); }
        this.addEventListener('qz-reset', _e => {
            if(this.correct != undefined){
                this.correct = undefined;
                this.generateAnswer();
                this.render();
            }
        });
        
        this.addEventListener('click', event => {
            const button = this.querySelector('button');
            if(event.target == button) {
                if(button.dataset.action === 'retry') {
                    this.correct = undefined;
                    this.generateAnswer();
                    this.render();
                    return;
                }
                this.correct = true;
                this.answerIndexToCategoryIndex.forEach((val, idx) => {
                    if(val !== this.userIndexToCategoryIndex[idx]) {
                        this.correct = false
                    }
                })
                if(!this.correct){
                    this.dispatchEvent(FailedEvent());
                } else {
                    this.dispatchEvent(SolvedEvent());
                }
                // alert(`Your answers were ${this.correct}!`);
                this.render();
            }
        })
        
        if(!this.initialized) {
            this.initialized = true;
            Array.from(this.querySelectorAll('qz-category')).forEach((category, category_index, categories) => {
                let titleNode = category.querySelector('qz-title');
                let tmpPick = parseInt(category.getAttribute('pick'), 10);
                if(titleNode) {
                    this.answersByCategories.push({
                        title: titleNode.innerHTML,
                        answers: Array.from(category.querySelectorAll('qz-answer')).map(a => a.innerHTML),
                        color: `hsl(${category_index/categories.length * 360} 80% 80%)`,
                        pick: !Number.isNaN(tmpPick) ? tmpPick : null
                    });
                } else {
                    this.answersByCategories[0].answers = Array.from(category.querySelectorAll('qz-answer')).map(a => a.innerHTML);
                }
                category.remove();
            });
            this.question = this.querySelector('qz-question')?.innerHTML;
        }

        this.generateAnswer();
        this.render();
    }

    generateAnswer(){
        const titled = this.answersByCategories.filter(({title}) => title);
        this.activeCategories = shuffle(titled).slice(0, this.maxCategories);

        // False positives: answers that belong to no displayed category —
        // the uncategorized pool plus the answers of hidden categories.
        const activeSet = new Set(this.activeCategories);
        const falsePositives = [
            ...this.answersByCategories[0].answers,
            ...this.answersByCategories.flatMap(category =>
                category.title && !activeSet.has(category) ? category.answers : []
            ),
        ];

        this.answers = shuffle([
            ...this.activeCategories.reduce((arr, category) => [
                ...arr,
                ...pickRandom(category.answers.map(answer => ({
                    categoryIndex: this.answersByCategories.indexOf(category),
                    content: answer
                })), category.pick)
            ], []),
            ...pickRandom(falsePositives.map(content => ({
                categoryIndex: 0,
                content
            })), this.maxDistractors)
        ]);
        this.answerIndexToCategoryIndex = this.answers.map(({categoryIndex}) => categoryIndex);
        this.userIndexToCategoryIndex = this.answers.map(() => 0)
    }

    render(){
        let renderQuestion = (question) => {
            return `${question ? `<div class="quizard-question">${question}</div>` : ''}`
        }

        let renderSelect = (answer_option) => {
            return `<div class='label empty'>z</div><select id="${answer_option}" name="answer_option_${answer_option}">
            ${this.answersByCategories.map(({title}, idx) => `<option value="${idx-1}" >${title ? idx-1 :''}</option>`)}
            </select>`;
        }

        let renderQuiz = (question) => {
            return `
                ${renderQuestion(question)}
                <div class="quizard-categories">
                ${shuffle(this.activeCategories).map((category) => {
                    const fullIndex = this.answersByCategories.indexOf(category);
                    return `<div class="quizard-category framed" tabIndex="0" index="${fullIndex-1}" style=".selected{background-color:red;}"><div class="label">${fullIndex}</div><div class="quizard-title">${category.title}</div></div>`;
                }).join('')}
                </div>
                <div class="quizard-answer-pool">
                ${this.answers.map(({content}, idx) => `<div class="framed" tabIndex="0">${renderSelect(idx)}<p>${content}</p></div>`).join('')}
                </div>
                <button>Evaluate</button>
            `;
        }

        let renderFailure = (question) => {
            return `
                ${renderQuestion(question)}
                <div class="quizard-categories">
                ${this.activeCategories.map((category) => {
                    const fullIndex = this.answersByCategories.indexOf(category);
                    return `<div class="quizard-category framed" index="${fullIndex-1}"><div class="label">${fullIndex}</div><div class="quizard-title">${category.title}</div></div>`;
                }).join('')}
                </div>
                <div class="quizard-answer-pool">
                ${this.answers.map(({content}, idx) => {
                    const isCorrect = this.answerIndexToCategoryIndex[idx] === this.userIndexToCategoryIndex[idx];
                    const answerIndex = this.answerIndexToCategoryIndex[idx];
                    const label = isCorrect
                        ? (answerIndex === 0 ? '–' : this.userIndexToCategoryIndex[idx])
                        : (answerIndex === 0 ? '✗' : `→ ${answerIndex}`);
                    return `<div class="framed ${isCorrect ? 'correct' : 'incorrect'}" tabIndex="0">
                    <div class="label">${label}</div>
                    <p>${content}</p>
                </div>`;
                }).join('')}
                </div>
                <button data-action="retry">Retry</button>
            `;
        }

        let renderSuccess = (question) => {
            return `
                ${renderQuestion(question)}
                <div class="quizard-categories">
                ${this.activeCategories.map((category) => {
                    const fullIndex = this.answersByCategories.indexOf(category);
                    return `<div class="quizard-category" index="${fullIndex-1}">
                    ${category.title}<div class="quizard-answers">${category.answers.map(answer => `<div class="framed correct">${answer}</div>`).join('')}</div></div>`;
                }).join('')}
                </div>
            `;
        }

        const template = this.correct === undefined ? `${renderQuiz(this.question)}` : this.correct ? `${renderSuccess(this.question)}` : `${renderFailure(this.question)}`;

        const previouslyFalse = this.correct !== undefined && !this.correct;
        this.innerHTML = `<div class="quizard-container qz-category ${previouslyFalse ? ' incorrect': ''}">${template}</div>`;

        // -- Postprocessing

        Array.from(this.querySelectorAll('select')).forEach((select, index) => {
            select.addEventListener('change', (event) => {
                alert(`Change answer ${index} to ${event.target.value}`)
            })
        })

        if(this.correct === undefined) {
            Array.from(this.querySelectorAll('.quizard-category')).forEach((category, index) => {
                let handler = (event) => {
                    const animationClass = 'qz-flash-select';
                    let categoryIndex = parseInt(category.getAttribute('index'), 10);

                    if(this.currentlySelectedCategory) {
                        if(this.currentlySelectedCategory == categoryIndex+1){
                            category.classList.remove('selected');
                            this.currentlySelectedCategory = 0;
                            playAnimation(category, animationClass);
                        } else{
                            // Another was selected...remove all from them
                            Array.from(this.querySelectorAll('.quizard-category')).forEach(cate => cate.classList.remove('selected'))
                            category.classList.add('selected')
                            this.currentlySelectedCategory = categoryIndex+1;
                            playAnimation(category, animationClass);
                        }
                    } else {
                        // Nobody else was selected... we can chill
                        category.classList.add('selected')
                        this.currentlySelectedCategory = categoryIndex+1;
                        playAnimation(category, animationClass);
                    }
                };

                category.addEventListener('click', handler);
                category.addEventListener('keyup', event => {
                    if(event.key === " "){
                        handler(event);
                    }
                });
            })

            Array.from(this.querySelectorAll('.quizard-answer-pool .framed')).forEach((poolItem, index) => {
                poolItem.addEventListener('click', () => {
                    this.userIndexToCategoryIndex[index] = this.currentlySelectedCategory;
                    let label = poolItem.querySelector('.label');
                    if(this.userIndexToCategoryIndex[index] !== 0){
                        label.classList.remove('empty');
                        label.innerHTML = `${this.userIndexToCategoryIndex[index]}`
                    }else {
                        label.classList.add('empty');
                        label.innerHTML = 'z'
                    }
                    label.classList.remove('jump');
                    void label.offsetWidth;
                    label.classList.add('jump');
                })
            })
        }
    }
}
