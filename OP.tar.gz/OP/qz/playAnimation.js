export function playAnimation(element, cssClass) {
    element.classList.remove(cssClass);
    void element.offsetWidth;
    element.classList.add(cssClass);
}