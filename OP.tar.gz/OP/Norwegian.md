<qz-quiz from="norwegian" to="english">
    <!-- https://naob.no/ordbok/ -->
    <qz-practice qz-level-id="vocab_norwegian2english_e787ede7-1746-4713-81ad-334254d8ac5b">
    <qz-flipcard>
        <qz-front>en reke</qz-front>
        <qz-back>a shrimp</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_f64b3799-8f2c-4a85-8f7c-ad0d7a992231">
    <qz-flipcard>
        <qz-front>en skapning</qz-front>
        <qz-back>a creature</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_bf3be58a-da77-42d9-bec3-a5004816fdf8">
    <qz-flipcard>
        <qz-front>å skape</qz-front>
        <qz-back>to create</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_2ca93a3d-0cb9-41df-9c64-ad5ed86f2fed">
    <qz-flipcard>
        <qz-front>å lage</qz-front>
        <qz-back>to make</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_579491fa-3e0c-49c2-9aa4-5bf6167f7573">
    <qz-flipcard>
        <qz-front>å kaste</qz-front>
        <qz-back>to cast</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_2561b67c-2a7f-47d2-9ddd-b99922156fc3">
    <qz-flipcard>
        <qz-front>en trolldom</qz-front>
        <qz-back>a sorcery</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_dea8db61-e1fa-46d8-af25-70732ff7123d">
    <qz-flipcard>
        <qz-front>å trekke</qz-front>
        <qz-back>to draw (a card)</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_cfb160ef-3e07-4223-b410-8cb726ceb938">
    <qz-flipcard>
        <qz-front>et kort</qz-front>
        <qz-back>a card</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_2971c1fa-88de-415e-934a-1af4e82517e8">
    <qz-flipcard>
        <qz-front>døds-</qz-front>
        <qz-back>death-</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_05a05b47-a7e9-426d-b6d9-ae0fb13f47f5">
    <qz-flipcard>
        <qz-front>rør</qz-front>
        <qz-back>touch</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_7bb91d20-77aa-44f9-bea9-fc624a446c37">
    <qz-flipcard>
        <qz-front>dødelig</qz-front>
        <qz-back>lethal</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_d1a8fab4-62c6-4611-b9c2-0b263d0c396b">
    <qz-flipcard>
        <qz-front>gravid</qz-front>
        <qz-back>pregnant</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_1acda074-067f-4d3f-9d12-8750515156a5">
    <qz-flipcard>
        <qz-front>kåt</qz-front>
        <qz-back>horny</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_90a9022e-c9cd-4438-9160-eea9ef0b048a">
    <qz-flipcard>
        <qz-front>våt</qz-front>
        <qz-back>wet</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_b82e29e1-d78c-4f40-bea6-cc40ccf14a25">
    <qz-flipcard>
        <qz-front>fuktig</qz-front>
        <qz-back>damp</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_a1e4f417-7b1e-4cbb-a4a0-3fb0b830e255">
    <qz-flipcard>
        <qz-front>alltid</qz-front>
        <qz-back>always</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_db1cf7d8-be95-4e1b-b05e-9ed02e054822">
    <qz-flipcard>
        <qz-front>webutvikler</qz-front>
        <qz-back>web developer</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_4919cfbe-6411-49fe-83f5-f5f342f53995">
    <qz-flipcard>
        <qz-front>å kjøpe</qz-front>
        <qz-back>to buy</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_887bd69d-d89a-49a8-b0d7-261a125577ff">
    <qz-flipcard>
        <qz-front>av og til</qz-front>
        <qz-back>sometimes</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_77d28d05-d642-44e9-9675-fdabcf71e9a9">
    <qz-flipcard>
        <qz-front>en brystvorte</qz-front>
        <qz-back>a nipple</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_e5d044bc-cc77-4b8a-aa23-fe41d12ecd17">
    <qz-flipcard>
        <qz-front>et bryst</qz-front>
        <qz-back>a breast</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_1d4e4238-f22d-42ca-a2a0-d5e06f898b54">
    <qz-flipcard>
        <qz-front>søt tann</qz-front>
        <qz-back>sweettooth</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_41807b42-e805-47e5-acbf-ea9859751c94">
    <qz-flipcard>
        <qz-front>honningen</qz-front>
        <qz-back>the honey</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_750d339a-e1ff-465c-9810-09e9c9bc6497">
    <qz-flipcard>
        <qz-front>en bie</qz-front>
        <qz-back>a bee</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_a1e1ba91-a4f3-48c0-9d3a-92243c795575">
    <qz-flipcard>
        <qz-front>en forskjell</qz-front>
        <qz-back>a difference</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_bd36bfbc-1668-43d2-9efc-878812b9d1d7">
    <qz-flipcard>
        <qz-front>en ljå</qz-front>
        <qz-back>a scythe</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_e787ede7-1746-4713-81ad-334254d8ac5b">
    <qz-flipcard>
        <qz-front>a shrimp</qz-front>
        <qz-back>en reke</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_f64b3799-8f2c-4a85-8f7c-ad0d7a992231">
    <qz-flipcard>
        <qz-front>a creature</qz-front>
        <qz-back>en skapning</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_bf3be58a-da77-42d9-bec3-a5004816fdf8">
    <qz-flipcard>
        <qz-front>to create</qz-front>
        <qz-back>å skape</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_2ca93a3d-0cb9-41df-9c64-ad5ed86f2fed">
    <qz-flipcard>
        <qz-front>to make</qz-front>
        <qz-back>å lage</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_579491fa-3e0c-49c2-9aa4-5bf6167f7573">
    <qz-flipcard>
        <qz-front>to cast</qz-front>
        <qz-back>å kaste</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_2561b67c-2a7f-47d2-9ddd-b99922156fc3">
    <qz-flipcard>
        <qz-front>a sorcery</qz-front>
        <qz-back>en trolldom</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_dea8db61-e1fa-46d8-af25-70732ff7123d">
    <qz-flipcard>
        <qz-front>to draw (a card)</qz-front>
        <qz-back>å trekke</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_cfb160ef-3e07-4223-b410-8cb726ceb938">
    <qz-flipcard>
        <qz-front>a card</qz-front>
        <qz-back>et kort</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_2971c1fa-88de-415e-934a-1af4e82517e8">
    <qz-flipcard>
        <qz-front>death-</qz-front>
        <qz-back>døds-</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_05a05b47-a7e9-426d-b6d9-ae0fb13f47f5">
    <qz-flipcard>
        <qz-front>touch</qz-front>
        <qz-back>rør</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_7bb91d20-77aa-44f9-bea9-fc624a446c37">
    <qz-flipcard>
        <qz-front>lethal</qz-front>
        <qz-back>dødelig</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_d1a8fab4-62c6-4611-b9c2-0b263d0c396b">
    <qz-flipcard>
        <qz-front>pregnant</qz-front>
        <qz-back>gravid</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_1acda074-067f-4d3f-9d12-8750515156a5">
    <qz-flipcard>
        <qz-front>horny</qz-front>
        <qz-back>kåt</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_90a9022e-c9cd-4438-9160-eea9ef0b048a">
    <qz-flipcard>
        <qz-front>wet</qz-front>
        <qz-back>våt</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_b82e29e1-d78c-4f40-bea6-cc40ccf14a25">
    <qz-flipcard>
        <qz-front>damp</qz-front>
        <qz-back>fuktig</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_a1e4f417-7b1e-4cbb-a4a0-3fb0b830e255">
    <qz-flipcard>
        <qz-front>always</qz-front>
        <qz-back>alltid</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_db1cf7d8-be95-4e1b-b05e-9ed02e054822">
    <qz-flipcard>
        <qz-front>web developer</qz-front>
        <qz-back>webutvikler</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_4919cfbe-6411-49fe-83f5-f5f342f53995">
    <qz-flipcard>
        <qz-front>to buy</qz-front>
        <qz-back>å kjøpe</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_887bd69d-d89a-49a8-b0d7-261a125577ff">
    <qz-flipcard>
        <qz-front>sometimes</qz-front>
        <qz-back>av og til</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_77d28d05-d642-44e9-9675-fdabcf71e9a9">
    <qz-flipcard>
        <qz-front>a nipple</qz-front>
        <qz-back>en brystvorte</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_e5d044bc-cc77-4b8a-aa23-fe41d12ecd17">
    <qz-flipcard>
        <qz-front>a breast</qz-front>
        <qz-back>et bryst</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_1d4e4238-f22d-42ca-a2a0-d5e06f898b54">
    <qz-flipcard>
        <qz-front>sweettooth</qz-front>
        <qz-back>søt tann</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_41807b42-e805-47e5-acbf-ea9859751c94">
    <qz-flipcard>
        <qz-front>the honey</qz-front>
        <qz-back>honningen</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_750d339a-e1ff-465c-9810-09e9c9bc6497">
    <qz-flipcard>
        <qz-front>a bee</qz-front>
        <qz-back>en bie</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_a1e1ba91-a4f3-48c0-9d3a-92243c795575">
    <qz-flipcard>
        <qz-front>a difference</qz-front>
        <qz-back>en forskjell</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_english2norwegian_bd36bfbc-1668-43d2-9efc-878812b9d1d7">
    <qz-flipcard>
        <qz-front>a scythe</qz-front>
        <qz-back>en ljå</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_559c9e21-860f-4542-8a78-a260964e9a47">
    <qz-flipcard>
        <qz-front>å snakke</qz-front>
        <qz-back>to speak</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_20daf234-2293-4b3d-aed0-3ef1403ce234">
    <qz-flipcard>
        <qz-front>hun</qz-front>
        <qz-back>she</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_5394f278-472c-4a32-bc71-1dd94c74d118">
    <qz-flipcard>
        <qz-front>han</qz-front>
        <qz-back>he</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_00a7fde5-9368-4902-ab66-fb466498acd0">
    <qz-flipcard>
        <qz-front>en hest</qz-front>
        <qz-back>a horse</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_ce3afd60-6ca8-48b2-89d8-92c75c31a311">
    <qz-flipcard>
        <qz-front>en ost</qz-front>
        <qz-back>a cheese</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_fdd4e413-1d94-41fe-b564-91eb23ee6105">
    <qz-flipcard>
        <qz-front>hebraisk</qz-front>
        <qz-back>Hebrew</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_7510dc7e-ce05-4041-abb5-a0bf7a340bfe">
    <qz-flipcard>
        <qz-front>å komme fra</qz-front>
        <qz-back>to come from</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_3ed46e84-37f6-4dbd-a886-97137b7116eb">
    <qz-flipcard>
        <qz-front>en kusin</qz-front>
        <qz-back>a cousin</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_fcef11df-01f4-4c4f-abb5-07a6347a1527">
    <qz-flipcard>
        <qz-front>å reise til</qz-front>
        <qz-back>to travel to</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_05617eed-a219-4740-b569-75cbe1cd0fe8">
    <qz-flipcard>
        <qz-front>alene</qz-front>
        <qz-back>alone</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_f04b36d8-7b68-434d-9810-777ffb1aea60">
    <qz-flipcard>
        <qz-front>Russland</qz-front>
        <qz-back>russia</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_8985e673-2aa0-4564-ac01-d98c7689868a">
    <qz-flipcard>
        <qz-front>en nordmann</qz-front>
        <qz-back>a norwegian</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_0e93614d-f5b9-4c4b-909a-890ed09846cc">
    <qz-flipcard>
        <qz-front>et hus</qz-front>
        <qz-back>a house</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_0b63ecf2-455b-4f18-b844-cd8ee2189bfb">
    <qz-flipcard>
        <qz-front>mange</qz-front>
        <qz-back>many</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_72514dfd-330c-4c80-9a62-57983e001d69">
    <qz-flipcard>
        <qz-front>land</qz-front>
        <qz-back>countries</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_91385e2e-9fa4-4043-9ec0-02dc0f166710">
    <qz-flipcard>
        <qz-front>å grense</qz-front>
        <qz-back>to border</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_2d972d65-7819-42fe-b96c-5dd26c5a8f45">
    <qz-flipcard>
        <qz-front>å har på seg</qz-front>
        <qz-back>to wear</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_3d2074a6-4e48-4ce1-b703-5936ec14a75e">
    <qz-flipcard>
        <qz-front>et bær</qz-front>
        <qz-back>a berry</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_823108a7-0879-4440-9d27-2f0101c70841">
    <qz-flipcard>
        <qz-front>å spise</qz-front>
        <qz-back>to eat</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_cd51bdbd-ab3d-48da-9880-af2acabf2f37">
    <qz-flipcard>
        <qz-front>selv</qz-front>
        <qz-back>even</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_efd03871-8834-473d-9213-db8fdc8cb59a">
    <qz-flipcard>
        <qz-front>en elefant</qz-front>
        <qz-back>an elephant</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_2a77f5f1-cfcf-4f9f-98d0-0c68ba92b59f">
    <qz-flipcard>
        <qz-front>å frykte</qz-front>
        <qz-back>to be afraid of</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_c74fcebb-425b-4925-bb04-43035ca84c04">
    <qz-flipcard>
        <qz-front>et bløtdyr</qz-front>
        <qz-back>a mollusc</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_0bb01174-1b32-4fbf-a725-a7cd10625069">
    <qz-flipcard>
        <qz-front>eller</qz-front>
        <qz-back>or</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_1052b1e8-8486-492a-b150-c4bcd6d77312">
    <qz-flipcard>
        <qz-front>en rekke</qz-front>
        <qz-back>a number of</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_b4a458b6-0ab5-4c5d-99e8-65388a4838ed">
    <qz-flipcard>
        <qz-front>høyst</qz-front>
        <qz-back>at most</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_92399488-51c1-466a-a49c-87f4ee195057">
    <qz-flipcard>
        <qz-front>omfatter</qz-front>
        <qz-back>includes/comprises</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_12c4d979-2e87-497a-b31b-5478486d09c9">
    <qz-flipcard>
        <qz-front>et blekk</qz-front>
        <qz-back>an ink</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_44f09b49-c261-4c95-ba46-8a09d20830ef">
    <qz-flipcard>
        <qz-front>en blekksprut</qz-front>
        <qz-back>a squid</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_81bf41bd-d3f3-4871-85c4-4834587b3051">
    <qz-flipcard>
        <qz-front>en fyllepenn</qz-front>
        <qz-back>a fountain pen</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_56c0e8f2-16f1-4683-8d73-606fc3af5cf5">
    <qz-flipcard>
        <qz-front>kjærest-</qz-front>
        <qz-back>dearest-</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_adc50a98-38c1-49ed-a8a1-cbb0bfac2ecd">
    <qz-flipcard>
        <qz-front>fri</qz-front>
        <qz-back>free</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_b9c0023a-bf48-41f5-aa2b-afcc788d67d6">
    <qz-flipcard>
        <qz-front>allerede</qz-front>
        <qz-back>already</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_a63fd494-6f8d-4c3e-8d4c-e6c03dd0d343">
    <qz-flipcard>
        <qz-front>å vaske</qz-front>
        <qz-back>to wash</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_53344db1-2ce0-447b-a325-4bc309fbf329">
    <qz-flipcard>
        <qz-front>å kysse</qz-front>
        <qz-back>to kiss</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_3ac98396-71b2-4216-9d9c-16551c73b833">
    <qz-flipcard>
        <qz-front>en sekk</qz-front>
        <qz-back>a backpack/a sack</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_7398456a-165d-4c22-8ee3-db66ed149761">
    <qz-flipcard>
        <qz-front>å sjekke</qz-front>
        <qz-back>to check</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_fca99b56-4ef5-415c-b6c0-fe74f90cd7c2">
    <qz-flipcard>
        <qz-front>sjuke</qz-front>
        <qz-back>sick</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_7de95b70-3a49-4b8f-9e0f-7db5371bbefd">
    <qz-flipcard>
        <qz-front>et folk</qz-front>
        <qz-back>people</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_bf79b624-5398-419f-8ba5-441410010833">
    <qz-flipcard>
        <qz-front>en alder</qz-front>
        <qz-back>an age</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_56ce2a94-a4cc-4cd9-b919-10fb75e64116">
    <qz-flipcard>
        <qz-front>et år</qz-front>
        <qz-back> a year</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_f50dd29c-2a54-4e7f-9113-e638f9fd042c">
    <qz-flipcard>
        <qz-front>å se</qz-front>
        <qz-back>to see</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_2465645c-a00c-4540-8152-f9ba1e89c70a">
    <qz-flipcard>
        <qz-front>en gruppe</qz-front>
        <qz-back>a group</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_fd6c6b8d-8f0d-4397-bea9-6573a5c8de21">
    <qz-flipcard>
        <qz-front>frisk</qz-front>
        <qz-back>healthy</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_d1ec548c-eb0b-42c3-b1b9-eb3f97a9dfe6">
    <qz-flipcard>
        <qz-front>å sjukemelde</qz-front>
        <qz-back>to call sick</qz-back>
    </qz-flipcard>
    </qz-practice>
    <qz-practice qz-level-id="vocab_norwegian2english_cda36bd3-8e55-4a02-8f7b-4e33ac42c969">
    <qz-flipcard>
        <qz-front>hissig</qz-front>
        <qz-back>heat/tension</qz-back>
    </qz-flipcard>
    </qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_7398456a-165d-4c22-8ee3-db66ed149761">
<qz-flipcard>
	<qz-front>to check</qz-front>
	<qz-back>å sjekke</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_fca99b56-4ef5-415c-b6c0-fe74f90cd7c2">
<qz-flipcard>
	<qz-front>sick</qz-front>
	<qz-back>sjuke</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_7de95b70-3a49-4b8f-9e0f-7db5371bbefd">
<qz-flipcard>
	<qz-front>people</qz-front>
	<qz-back>et folk</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_bf79b624-5398-419f-8ba5-441410010833">
<qz-flipcard>
	<qz-front>an age</qz-front>
	<qz-back>en alder</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_56ce2a94-a4cc-4cd9-b919-10fb75e64116">
<qz-flipcard>
	<qz-front> a year</qz-front>
	<qz-back>et år</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_f50dd29c-2a54-4e7f-9113-e638f9fd042c">
<qz-flipcard>
	<qz-front>to see</qz-front>
	<qz-back>å se</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_2465645c-a00c-4540-8152-f9ba1e89c70a">
<qz-flipcard>
	<qz-front>a group</qz-front>
	<qz-back>en gruppe</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_fd6c6b8d-8f0d-4397-bea9-6573a5c8de21">
<qz-flipcard>
	<qz-front>healthy</qz-front>
	<qz-back>frisk</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_d1ec548c-eb0b-42c3-b1b9-eb3f97a9dfe6">
<qz-flipcard>
	<qz-front>to call sick</qz-front>
	<qz-back>å sjukemelde</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_cda36bd3-8e55-4a02-8f7b-4e33ac42c969">
<qz-flipcard>
	<qz-front>heat/tension</qz-front>
	<qz-back>hissig</qz-back>
</qz-flipcard>
</qz-practice>

<qz-practice qz-level-id="vocab_english2norwegian_2f65b289-9054-4ec6-b79e-a3831aa46725">
<qz-flipcard>
    <qz-front>fresh</qz-front>
    <qz-back>fresk</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_6bc9602c-72b0-4fe2-bb4b-1f814d744a27">
<qz-flipcard>
    <qz-front>iron</qz-front>
    <qz-back>jern</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_07e73506-ee09-4f78-83ff-b19425b61c55">
<qz-flipcard>
    <qz-front>copper</qz-front>
    <qz-back>kopper</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_4acdd66d-cd1a-4528-a0ae-c63a500be3ae">
<qz-flipcard>
    <qz-front>gold</qz-front>
    <qz-back>gull</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_db33d024-37f1-497f-abed-82f96b42ce1b">
<qz-flipcard>
    <qz-front>a diamond</qz-front>
    <qz-back>en diamant</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_c6cb5ab4-d1df-4c91-b8ab-e4e0365d9c5f">
<qz-flipcard>
    <qz-front>a crab</qz-front>
    <qz-back>en krabbe</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_51bb8d17-a01e-4393-ac83-68a37eef4a9d">
<qz-flipcard>
    <qz-front>a pick</qz-front>
    <qz-back>en hakke</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_1f582a49-bfc8-4cd8-a5b3-0210b4eec5c2">
<qz-flipcard>
    <qz-front>a 3D model</qz-front>
    <qz-back>en 3D-modell</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_23abce5b-b8b0-4797-9fc7-6904a764f827">
<qz-flipcard>
    <qz-front>good luck</qz-front>
    <qz-back>hell og lykke</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_fa0c8c20-34d3-4cf2-b42b-9b4ab763768c">
<qz-flipcard>
    <qz-front>save and exit</qz-front>
    <qz-back>lagre og avslutt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_bc013268-80be-4d13-98e5-4fcd3ec05bcf">
<qz-flipcard>
    <qz-front>to crush</qz-front>
    <qz-back>å knuse</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_16ceb7fe-db44-4891-93c2-ecc162257b48">
<qz-flipcard>
    <qz-front>chaos</qz-front>
    <qz-back>kaos</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_a71105eb-f40e-4807-9ef9-d3d0bf790665">
<qz-flipcard>
    <qz-front>become</qz-front>
    <qz-back>bli</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_907ea15c-55f0-4f4a-9f5d-c03b1a275f4f">
<qz-flipcard>
    <qz-front>fun</qz-front>
    <qz-back>gøy</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_8cba017e-2192-4dca-9214-769d68bee3f4">
<qz-flipcard>
    <qz-front>to miss</qz-front>
    <qz-back>å savne</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_93c4809c-fd78-4d7a-ae07-a1528ba444ac">
<qz-flipcard>
    <qz-front>a weekend</qz-front>
    <qz-back>en helg</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_55f354b4-0b34-4d33-934a-82772eddd803">
<qz-flipcard>
    <qz-front>to receive</qz-front>
    <qz-back>å motta</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_71b5b82f-55c3-448a-a3a1-d7b6809d25f2">
<qz-flipcard>
    <qz-front>to play</qz-front>
    <qz-back>å spille</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_fa8bb7a4-4585-485c-9303-93f1b125386f">
<qz-flipcard>
    <qz-front>sound</qz-front>
    <qz-back>lyd</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_3bcbf5ce-ebb0-4b6f-b191-076fe92afd43">
<qz-flipcard>
    <qz-front>developer</qz-front>
    <qz-back>utvikler</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_dec6efd9-7072-4b02-b525-a6570b4fc3b1">
<qz-flipcard>
    <qz-front>to hide</qz-front>
    <qz-back>å skjule</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_25243f04-f9bd-4802-8454-88f960228768">
<qz-flipcard>
    <qz-front>a curse</qz-front>
    <qz-back>en forbannelse</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_3be774e3-acba-45e5-9b83-c55f066cfe26">
<qz-flipcard>
    <qz-front>a troll</qz-front>
    <qz-back>en troll</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_b833772d-e6ea-4ce2-bdbf-e7e8c1ee798b">
<qz-flipcard>
    <qz-front>a spider</qz-front>
    <qz-back>en edderkopp</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_36cfaafd-fbc8-4fb7-a794-507a2793ab26">
<qz-flipcard>
    <qz-front>a wasp</qz-front>
    <qz-back>en veps</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_b4e8cc55-932d-4616-9de5-53059d2ed72b">
<qz-flipcard>
    <qz-front>a fly</qz-front>
    <qz-back>en flue</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_7c45aed7-29d6-437d-a251-ce286dd981cc">
<qz-flipcard>
    <qz-front>a pig</qz-front>
    <qz-back>en gris</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_79502aaf-2362-4ea3-9940-8e95df260798">
<qz-flipcard>
    <qz-front>a sheep</qz-front>
    <qz-back>en sau</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_7111d571-9612-4ea9-8424-13a853e74359">
<qz-flipcard>
    <qz-front>a head</qz-front>
    <qz-back>et hode</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_88db8816-4d16-4337-baed-872b2b8a731f">
<qz-flipcard>
    <qz-front>to refuse</qz-front>
    <qz-back>å nekte</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_31d97fbc-636e-4a0f-ae80-358d4f83935d">
<qz-flipcard>
    <qz-front>a world</qz-front>
    <qz-back>en verden</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_2f65b289-9054-4ec6-b79e-a3831aa46725">
<qz-flipcard>
    <qz-front>fresk</qz-front>
    <qz-back>fresh</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_6bc9602c-72b0-4fe2-bb4b-1f814d744a27">
<qz-flipcard>
    <qz-front>jern</qz-front>
    <qz-back>iron</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_07e73506-ee09-4f78-83ff-b19425b61c55">
<qz-flipcard>
    <qz-front>kopper</qz-front>
    <qz-back>copper</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_4acdd66d-cd1a-4528-a0ae-c63a500be3ae">
<qz-flipcard>
    <qz-front>gull</qz-front>
    <qz-back>gold</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_db33d024-37f1-497f-abed-82f96b42ce1b">
<qz-flipcard>
    <qz-front>en diamant</qz-front>
    <qz-back>a diamond</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_c6cb5ab4-d1df-4c91-b8ab-e4e0365d9c5f">
<qz-flipcard>
    <qz-front>en krabbe</qz-front>
    <qz-back>a crab</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_51bb8d17-a01e-4393-ac83-68a37eef4a9d">
<qz-flipcard>
    <qz-front>en hakke</qz-front>
    <qz-back>a pick</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_1f582a49-bfc8-4cd8-a5b3-0210b4eec5c2">
<qz-flipcard>
    <qz-front>en 3D-modell</qz-front>
    <qz-back>a 3D model</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_23abce5b-b8b0-4797-9fc7-6904a764f827">
<qz-flipcard>
    <qz-front>hell og lykke</qz-front>
    <qz-back>good luck</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_fa0c8c20-34d3-4cf2-b42b-9b4ab763768c">
<qz-flipcard>
    <qz-front>lagre og avslutt</qz-front>
    <qz-back>save and exit</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_bc013268-80be-4d13-98e5-4fcd3ec05bcf">
<qz-flipcard>
    <qz-front>å knuse</qz-front>
    <qz-back>to crush</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_16ceb7fe-db44-4891-93c2-ecc162257b48">
<qz-flipcard>
    <qz-front>kaos</qz-front>
    <qz-back>chaos</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_a71105eb-f40e-4807-9ef9-d3d0bf790665">
<qz-flipcard>
    <qz-front>bli</qz-front>
    <qz-back>become</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_907ea15c-55f0-4f4a-9f5d-c03b1a275f4f">
<qz-flipcard>
    <qz-front>gøy</qz-front>
    <qz-back>fun</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_8cba017e-2192-4dca-9214-769d68bee3f4">
<qz-flipcard>
    <qz-front>å savne</qz-front>
    <qz-back>to miss</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_93c4809c-fd78-4d7a-ae07-a1528ba444ac">
<qz-flipcard>
    <qz-front>en helg</qz-front>
    <qz-back>a weekend</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_55f354b4-0b34-4d33-934a-82772eddd803">
<qz-flipcard>
    <qz-front>å motta</qz-front>
    <qz-back>to receive</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_71b5b82f-55c3-448a-a3a1-d7b6809d25f2">
<qz-flipcard>
    <qz-front>å spille</qz-front>
    <qz-back>to play</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_fa8bb7a4-4585-485c-9303-93f1b125386f">
<qz-flipcard>
    <qz-front>lyd</qz-front>
    <qz-back>sound</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_3bcbf5ce-ebb0-4b6f-b191-076fe92afd43">
<qz-flipcard>
    <qz-front>utvikler</qz-front>
    <qz-back>developer</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_dec6efd9-7072-4b02-b525-a6570b4fc3b1">
<qz-flipcard>
    <qz-front>å skjule</qz-front>
    <qz-back>to hide</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_25243f04-f9bd-4802-8454-88f960228768">
<qz-flipcard>
    <qz-front>en forbannelse</qz-front>
    <qz-back>a curse</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_3be774e3-acba-45e5-9b83-c55f066cfe26">
<qz-flipcard>
    <qz-front>en troll</qz-front>
    <qz-back>a troll</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_b833772d-e6ea-4ce2-bdbf-e7e8c1ee798b">
<qz-flipcard>
    <qz-front>en edderkopp</qz-front>
    <qz-back>a spider</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_36cfaafd-fbc8-4fb7-a794-507a2793ab26">
<qz-flipcard>
    <qz-front>en veps</qz-front>
    <qz-back>a wasp</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_b4e8cc55-932d-4616-9de5-53059d2ed72b">
<qz-flipcard>
    <qz-front>en flue</qz-front>
    <qz-back>a fly</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_7c45aed7-29d6-437d-a251-ce286dd981cc">
<qz-flipcard>
    <qz-front>en gris</qz-front>
    <qz-back>a pig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_79502aaf-2362-4ea3-9940-8e95df260798">
<qz-flipcard>
    <qz-front>en sau</qz-front>
    <qz-back>a sheep</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_7111d571-9612-4ea9-8424-13a853e74359">
<qz-flipcard>
    <qz-front>et hode</qz-front>
    <qz-back>a head</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_88db8816-4d16-4337-baed-872b2b8a731f">
<qz-flipcard>
    <qz-front>å nekte</qz-front>
    <qz-back>to refuse</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_31d97fbc-636e-4a0f-ae80-358d4f83935d">
<qz-flipcard>
    <qz-front>en verden</qz-front>
    <qz-back>a world</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_cdb5aa75-c720-4e53-9458-8294d303f402">
<qz-flipcard>
	<qz-front>ha det (bra)</qz-front>
	<qz-back>good bye</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_53b76b86-9882-4199-9d03-91eae60651ce">
<qz-flipcard>
	<qz-front>en landsby</qz-front>
	<qz-back>a village</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_0bdc09a4-46a9-4301-92d5-7323ce415da5">
<qz-flipcard>
	<qz-front>å bo</qz-front>
	<qz-back>to live (in)</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_d7265912-087a-46ff-ac24-1e95282af04a">
<qz-flipcard>
	<qz-front>en skole</qz-front>
	<qz-back>a school</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_d9d75b03-e31b-4bfe-87bf-8acb1d5c6b7b">
<qz-flipcard>
	<qz-front>en foss</qz-front>
	<qz-back>a waterfall</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_77148c34-4d1d-4b16-89e1-3b8998520282">
<qz-flipcard>
	<qz-front>om</qz-front>
	<qz-back>if/about</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_9f1b055a-da59-4713-a248-a046fb183196">
<qz-flipcard>
	<qz-front>ærlig</qz-front>
	<qz-back>honest</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_5abb2783-616c-44f3-80d6-e9f9f0fc3ea9">
<qz-flipcard>
	<qz-front>en øl</qz-front>
	<qz-back>a beer</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_d56cbf02-8a7d-4ca5-9e5d-dd9414b3e806">
<qz-flipcard>
	<qz-front>å åpne</qz-front>
	<qz-back>to open</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_08d7a12c-0f3c-4d2c-8b8f-e5d187b88c58">
<qz-flipcard>
	<qz-front>en røyk</qz-front>
	<qz-back>smoke</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_d928b564-c441-45cc-9630-6905b8d06c4a">
<qz-flipcard>
	<qz-front>glad</qz-front>
	<qz-back>happy</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_9a2db8e9-eaf5-4cfb-b822-b3c1703c6ca5">
<qz-flipcard>
	<qz-front>herlig</qz-front>
	<qz-back>wonderful</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_d5cd9f73-e1a3-41d3-ab13-ec878539fc5c">
<qz-flipcard>
	<qz-front>meg</qz-front>
	<qz-back>my</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_e81460f5-84c7-4ba0-858c-e537cd096cd6">
<qz-flipcard>
	<qz-front>deg</qz-front>
	<qz-back>your</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_ebb6cfaa-5bbb-48ac-8f41-b695d7c75576">
<qz-flipcard>
	<qz-front>seg</qz-front>
	<qz-back>themselves</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_80dc5805-a55b-4cbe-bd16-c0e8d8ddc662">
<qz-flipcard>
	<qz-front>kjemi</qz-front>
	<qz-back>chemistry</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_9e076390-680c-4c68-bd8c-f978135f5f31">
<qz-flipcard>
	<qz-front>tjue</qz-front>
	<qz-back>twenty</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_20687450-4bf2-477f-9531-4edd06539d6c">
<qz-flipcard>
	<qz-front>tj</qz-front>
	<qz-back>(welp/well)</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_bd78757b-fe1c-4128-a8f6-b80686496c2a">
<qz-flipcard>
	<qz-front>gjerne</qz-front>
	<qz-back>gladly</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_c94bcbd5-6083-4bb3-9870-2bc63f016bdd">
<qz-flipcard>
	<qz-front>å hjelpe</qz-front>
	<qz-back>to help</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_4ebf37f1-fa20-4efb-8c2f-0e7da14958db">
<qz-flipcard>
	<qz-front>en stasjon</qz-front>
	<qz-back>a station</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_4604a285-13a3-441d-9e6b-ab7b05c668e9">
<qz-flipcard>
	<qz-front>beskjeden</qz-front>
	<qz-back>modest</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_f60db833-c516-4bec-a991-20a42ea05342">
<qz-flipcard>
	<qz-front>å slippe</qz-front>
	<qz-back>to let go(not need)</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_122567de-0d3d-46f7-9329-a66d040b7861">
<qz-flipcard>
	<qz-front>en regning</qz-front>
	<qz-back>a bill</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_8d6b90cd-c8d9-4e00-99b9-7d1ebd047e96">
<qz-flipcard>
	<qz-front>et tegn</qz-front>
	<qz-back>a sign</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_d65d7665-0476-4ab2-8c8d-2dd45ecf8494">
<qz-flipcard>
	<qz-front>en nagl</qz-front>
	<qz-back>a fingernail</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_25629753-b09b-4f5d-9ef3-0f9fa12d13f3">
<qz-flipcard>
	<qz-front>en døgn</qz-front>
	<qz-back>a 24 hour day</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_5164c713-1ef6-4c13-b548-3e78b50a5d28">
<qz-flipcard>
	<qz-front>en dag</qz-front>
	<qz-back>a day</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_fc615e69-630b-44dc-adb8-46c555cd2d05">
<qz-flipcard>
	<qz-front>hva</qz-front>
	<qz-back>what</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_6dac0fef-63cb-4459-aa52-86b48a434642">
<qz-flipcard>
	<qz-front>en jord</qz-front>
	<qz-back>an earth</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_0eb44f2c-fb8a-47d7-a58e-9427dd82bb84">
<qz-flipcard>
	<qz-front>en hånd</qz-front>
	<qz-back>a hand</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_23fea064-14b8-4d00-98c5-ccb7c1524ed1">
<qz-flipcard>
	<qz-front>et skip</qz-front>
	<qz-back>a ship</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_c0fbf35d-3fa3-4954-816d-856467d50a1c">
<qz-flipcard>
	<qz-front>et romskip</qz-front>
	<qz-back>a spaceship</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_fd2d20d8-323c-4dbf-a517-83796e1bd76a">
<qz-flipcard>
	<qz-front>en geit</qz-front>
	<qz-back>a goat</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_cdb5aa75-c720-4e53-9458-8294d303f402">
<qz-flipcard>
	<qz-front>good bye</qz-front>
	<qz-back>ha det (bra)</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_53b76b86-9882-4199-9d03-91eae60651ce">
<qz-flipcard>
	<qz-front>a village</qz-front>
	<qz-back>en landsby</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_0bdc09a4-46a9-4301-92d5-7323ce415da5">
<qz-flipcard>
	<qz-front>to live (in)</qz-front>
	<qz-back>å bo</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_d7265912-087a-46ff-ac24-1e95282af04a">
<qz-flipcard>
	<qz-front>a school</qz-front>
	<qz-back>en skole</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_d9d75b03-e31b-4bfe-87bf-8acb1d5c6b7b">
<qz-flipcard>
	<qz-front>a waterfall</qz-front>
	<qz-back>en foss</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_77148c34-4d1d-4b16-89e1-3b8998520282">
<qz-flipcard>
	<qz-front>if/about</qz-front>
	<qz-back>om</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_9f1b055a-da59-4713-a248-a046fb183196">
<qz-flipcard>
	<qz-front>honest</qz-front>
	<qz-back>ærlig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_5abb2783-616c-44f3-80d6-e9f9f0fc3ea9">
<qz-flipcard>
	<qz-front>a beer</qz-front>
	<qz-back>en øl</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_d56cbf02-8a7d-4ca5-9e5d-dd9414b3e806">
<qz-flipcard>
	<qz-front>to open</qz-front>
	<qz-back>å åpne</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_08d7a12c-0f3c-4d2c-8b8f-e5d187b88c58">
<qz-flipcard>
	<qz-front>smoke</qz-front>
	<qz-back>en røyk</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_d928b564-c441-45cc-9630-6905b8d06c4a">
<qz-flipcard>
	<qz-front>happy</qz-front>
	<qz-back>glad</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_9a2db8e9-eaf5-4cfb-b822-b3c1703c6ca5">
<qz-flipcard>
	<qz-front>wonderful</qz-front>
	<qz-back>herlig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_d5cd9f73-e1a3-41d3-ab13-ec878539fc5c">
<qz-flipcard>
	<qz-front>my</qz-front>
	<qz-back>meg</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_e81460f5-84c7-4ba0-858c-e537cd096cd6">
<qz-flipcard>
	<qz-front>your</qz-front>
	<qz-back>deg</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_ebb6cfaa-5bbb-48ac-8f41-b695d7c75576">
<qz-flipcard>
	<qz-front>themselves</qz-front>
	<qz-back>seg</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_80dc5805-a55b-4cbe-bd16-c0e8d8ddc662">
<qz-flipcard>
	<qz-front>chemistry</qz-front>
	<qz-back>kjemi</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_9e076390-680c-4c68-bd8c-f978135f5f31">
<qz-flipcard>
	<qz-front>twenty</qz-front>
	<qz-back>tjue</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_20687450-4bf2-477f-9531-4edd06539d6c">
<qz-flipcard>
	<qz-front>(welp/well)</qz-front>
	<qz-back>tj</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_bd78757b-fe1c-4128-a8f6-b80686496c2a">
<qz-flipcard>
	<qz-front>gladly</qz-front>
	<qz-back>gjerne</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_c94bcbd5-6083-4bb3-9870-2bc63f016bdd">
<qz-flipcard>
	<qz-front>to help</qz-front>
	<qz-back>å hjelpe</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_4ebf37f1-fa20-4efb-8c2f-0e7da14958db">
<qz-flipcard>
	<qz-front>a station</qz-front>
	<qz-back>en stasjon</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_4604a285-13a3-441d-9e6b-ab7b05c668e9">
<qz-flipcard>
	<qz-front>modest</qz-front>
	<qz-back>beskjeden</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_f60db833-c516-4bec-a991-20a42ea05342">
<qz-flipcard>
	<qz-front>to let go(not need)</qz-front>
	<qz-back>å slippe</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_122567de-0d3d-46f7-9329-a66d040b7861">
<qz-flipcard>
	<qz-front>a bill</qz-front>
	<qz-back>en regning</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_8d6b90cd-c8d9-4e00-99b9-7d1ebd047e96">
<qz-flipcard>
	<qz-front>a sign</qz-front>
	<qz-back>et tegn</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_d65d7665-0476-4ab2-8c8d-2dd45ecf8494">
<qz-flipcard>
	<qz-front>a fingernail</qz-front>
	<qz-back>en nagl</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_25629753-b09b-4f5d-9ef3-0f9fa12d13f3">
<qz-flipcard>
	<qz-front>a 24 hour day</qz-front>
	<qz-back>en døgn</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_5164c713-1ef6-4c13-b548-3e78b50a5d28">
<qz-flipcard>
	<qz-front>a day</qz-front>
	<qz-back>en dag</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_fc615e69-630b-44dc-adb8-46c555cd2d05">
<qz-flipcard>
	<qz-front>what</qz-front>
	<qz-back>hva</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_6dac0fef-63cb-4459-aa52-86b48a434642">
<qz-flipcard>
	<qz-front>an earth</qz-front>
	<qz-back>en jord</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_0eb44f2c-fb8a-47d7-a58e-9427dd82bb84">
<qz-flipcard>
	<qz-front>a hand</qz-front>
	<qz-back>en hånd</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_23fea064-14b8-4d00-98c5-ccb7c1524ed1">
<qz-flipcard>
	<qz-front>a ship</qz-front>
	<qz-back>et skip</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_c0fbf35d-3fa3-4954-816d-856467d50a1c">
<qz-flipcard>
	<qz-front>a spaceship</qz-front>
	<qz-back>et romskip</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_fd2d20d8-323c-4dbf-a517-83796e1bd76a">
<qz-flipcard>
	<qz-front>a goat</qz-front>
	<qz-back>en geit</qz-back>
</qz-flipcard>
</qz-practice>


<qz-practice qz-level-id="vocab_norwegian2english_26aa7702-2e8d-4c52-aa1b-87e998fb2a51">
<qz-flipcard>
	<qz-front>en krok</qz-front>
	<qz-back>a corner</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_805d1ccc-ee98-460d-9f1e-08c442d58ac4">
<qz-flipcard>
	<qz-front>skarp</qz-front>
	<qz-back>sharp</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_b8bc7e6a-c2de-45f2-badb-147bd1a33aec">
<qz-flipcard>
	<qz-front>godt</qz-front>
	<qz-back>good</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_f3304448-1c9f-4a01-b098-ff415633fafe">
<qz-flipcard>
	<qz-front>en katt</qz-front>
	<qz-back>a cat</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_61209f32-4be4-4a69-b590-562c2b4c0d84">
<qz-flipcard>
	<qz-front>et glass</qz-front>
	<qz-back>a glas</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_0e0170f7-7f69-48af-b3ca-8eca143b3358">
<qz-flipcard>
	<qz-front>en fisk</qz-front>
	<qz-back>a fish</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_8b15a076-e232-479e-975d-1ab52d6efbbb">
<qz-flipcard>
	<qz-front>en klokke</qz-front>
	<qz-back>a clock</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_0359f328-85c3-4e7b-8ae4-3a522f2f501f">
<qz-flipcard>
	<qz-front>en flaske</qz-front>
	<qz-back>a bottle</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_1978104f-406a-4e31-9255-88373f57b181">
<qz-flipcard>
	<qz-front>et hus</qz-front>
	<qz-back>a house</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_67458afb-62cd-46ef-970c-2d32295cd4c1">
<qz-flipcard>
	<qz-front>en bil</qz-front>
	<qz-back>a car</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_3982efaf-622f-4187-8d80-6c048d3d8bef">
<qz-flipcard>
	<qz-front>et skap</qz-front>
	<qz-back>a closet</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_30dd3d82-2987-4502-859d-cb0edeb9ba69">
<qz-flipcard>
	<qz-front>å gå</qz-front>
	<qz-back>to go</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_cd261250-0511-47d6-8444-33c047ace073">
<qz-flipcard>
	<qz-front>å tro</qz-front>
	<qz-back>to believe</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_1e7cf5cf-e4bc-4293-8aac-fc0823558cf8">
<qz-flipcard>
	<qz-front>en skive</qz-front>
	<qz-back>a plate</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_49c0eec7-6bc5-40e9-beea-287e72315b6c">
<qz-flipcard>
	<qz-front>Har du ...?</qz-front>
	<qz-back>Do you have (collocual) ...?</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_3fd7b5bb-ee40-4d3f-9857-a77b13a55f6d">
<qz-flipcard>
	<qz-front>Har de ...?</qz-front>
	<qz-back>Do you (formal) have ...?</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_9229c005-db7e-4bf3-8ca2-bf5ed0df1fd9">
<qz-flipcard>
	<qz-front>en kaffe</qz-front>
	<qz-back>a coffee</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_4f66d90d-c59a-4511-bd3c-623cac9c576d">
<qz-flipcard>
	<qz-front>en te</qz-front>
	<qz-back>a tea</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_45719f00-7882-41fa-b006-38f321442c06">
<qz-flipcard>
	<qz-front>et skjort</qz-front>
	<qz-back>a shirt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_66b67a06-824d-461c-9400-afabbc4d2643">
<qz-flipcard>
	<qz-front>et frimerke</qz-front>
	<qz-back>a post stamp</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_bd257b1e-c0c1-49eb-ad97-01400cdc9758">
<qz-flipcard>
	<qz-front>ja</qz-front>
	<qz-back>yes</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_7194ddce-f44e-4ca2-a01b-64eb292595a2">
<qz-flipcard>
	<qz-front>nei</qz-front>
	<qz-back>no</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_5222e54c-26bf-473a-b169-b61fb473350e">
<qz-flipcard>
	<qz-front>Jeg vil gjerne ha ...</qz-front>
	<qz-back>I would like to have ...</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_43344cb8-2b54-4ef6-9ae9-5b09ae60d0c9">
<qz-flipcard>
	<qz-front>Hvor er ...?</qz-front>
	<qz-back>Where is ...?</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_c66a12af-6e67-4a5f-bb61-17add8471c7d">
<qz-flipcard>
	<qz-front>et hotell</qz-front>
	<qz-back>a hotel</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_0feb53fa-c475-4396-a663-401b757c9c4d">
<qz-flipcard>
	<qz-front>til høyre</qz-front>
	<qz-back>to the right</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_2e2b22d2-e7db-4ff7-97f0-dafc39cf93c9">
<qz-flipcard>
	<qz-front>til venstre</qz-front>
	<qz-back>to the left</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_e887666d-8439-48f9-b3a5-eb2d7b0e49b6">
<qz-flipcard>
	<qz-front>rett fram</qz-front>
	<qz-back>straight ahead</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_0dfcf345-8eb5-41b1-9d7b-e4d54d12139d">
<qz-flipcard>
	<qz-front>en hund</qz-front>
	<qz-back>a dog</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_b66e843d-0a1b-4e29-bfa1-4e64c7ab93d1">
<qz-flipcard>
	<qz-front>en sol</qz-front>
	<qz-back>a sun</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_8a72efa5-6a5b-4581-b503-3dcc17868ebe">
<qz-flipcard>
	<qz-front>en kone/kona</qz-front>
	<qz-back>a wife/the wife</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_f4c8a862-3f03-4d84-8478-9301814d89cb">
<qz-flipcard>
	<qz-front>et barn</qz-front>
	<qz-back>a child</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_3a9e6983-3674-4b3f-b875-3a414953e138">
<qz-flipcard>
	<qz-front>en gate</qz-front>
	<qz-back>a street</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_26aa7702-2e8d-4c52-aa1b-87e998fb2a51">
<qz-flipcard>
	<qz-front>a corner</qz-front>
	<qz-back>en krok</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_805d1ccc-ee98-460d-9f1e-08c442d58ac4">
<qz-flipcard>
	<qz-front>sharp</qz-front>
	<qz-back>skarp</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_b8bc7e6a-c2de-45f2-badb-147bd1a33aec">
<qz-flipcard>
	<qz-front>good</qz-front>
	<qz-back>godt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_f3304448-1c9f-4a01-b098-ff415633fafe">
<qz-flipcard>
	<qz-front>a cat</qz-front>
	<qz-back>en katt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_61209f32-4be4-4a69-b590-562c2b4c0d84">
<qz-flipcard>
	<qz-front>a glas</qz-front>
	<qz-back>et glass</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_0e0170f7-7f69-48af-b3ca-8eca143b3358">
<qz-flipcard>
	<qz-front>a fish</qz-front>
	<qz-back>en fisk</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_8b15a076-e232-479e-975d-1ab52d6efbbb">
<qz-flipcard>
	<qz-front>a clock</qz-front>
	<qz-back>en klokke</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_0359f328-85c3-4e7b-8ae4-3a522f2f501f">
<qz-flipcard>
	<qz-front>a bottle</qz-front>
	<qz-back>en flaske</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_1978104f-406a-4e31-9255-88373f57b181">
<qz-flipcard>
	<qz-front>a house</qz-front>
	<qz-back>et hus</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_67458afb-62cd-46ef-970c-2d32295cd4c1">
<qz-flipcard>
	<qz-front>a car</qz-front>
	<qz-back>en bil</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_3982efaf-622f-4187-8d80-6c048d3d8bef">
<qz-flipcard>
	<qz-front>a closet</qz-front>
	<qz-back>et skap</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_30dd3d82-2987-4502-859d-cb0edeb9ba69">
<qz-flipcard>
	<qz-front>to go</qz-front>
	<qz-back>å gå</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_cd261250-0511-47d6-8444-33c047ace073">
<qz-flipcard>
	<qz-front>to believe</qz-front>
	<qz-back>å tro</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_1e7cf5cf-e4bc-4293-8aac-fc0823558cf8">
<qz-flipcard>
	<qz-front>a plate</qz-front>
	<qz-back>en skive</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_49c0eec7-6bc5-40e9-beea-287e72315b6c">
<qz-flipcard>
	<qz-front>Do you have (collocual) ...?</qz-front>
	<qz-back>Har du ...?</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_3fd7b5bb-ee40-4d3f-9857-a77b13a55f6d">
<qz-flipcard>
	<qz-front>Do you (formal) have ...?</qz-front>
	<qz-back>Har de ...?</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_9229c005-db7e-4bf3-8ca2-bf5ed0df1fd9">
<qz-flipcard>
	<qz-front>a coffee</qz-front>
	<qz-back>en kaffe</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_4f66d90d-c59a-4511-bd3c-623cac9c576d">
<qz-flipcard>
	<qz-front>a tea</qz-front>
	<qz-back>en te</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_45719f00-7882-41fa-b006-38f321442c06">
<qz-flipcard>
	<qz-front>a shirt</qz-front>
	<qz-back>et skjort</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_66b67a06-824d-461c-9400-afabbc4d2643">
<qz-flipcard>
	<qz-front>a post stamp</qz-front>
	<qz-back>et frimerke</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_bd257b1e-c0c1-49eb-ad97-01400cdc9758">
<qz-flipcard>
	<qz-front>yes</qz-front>
	<qz-back>ja</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_7194ddce-f44e-4ca2-a01b-64eb292595a2">
<qz-flipcard>
	<qz-front>no</qz-front>
	<qz-back>nei</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_5222e54c-26bf-473a-b169-b61fb473350e">
<qz-flipcard>
	<qz-front>I would like to have ...</qz-front>
	<qz-back>Jeg vil gjerne ha ...</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_43344cb8-2b54-4ef6-9ae9-5b09ae60d0c9">
<qz-flipcard>
	<qz-front>Where is ...?</qz-front>
	<qz-back>Hvor er ...?</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_c66a12af-6e67-4a5f-bb61-17add8471c7d">
<qz-flipcard>
	<qz-front>a hotel</qz-front>
	<qz-back>et hotell</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_0feb53fa-c475-4396-a663-401b757c9c4d">
<qz-flipcard>
	<qz-front>to the right</qz-front>
	<qz-back>til høyre</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_2e2b22d2-e7db-4ff7-97f0-dafc39cf93c9">
<qz-flipcard>
	<qz-front>to the left</qz-front>
	<qz-back>til venstre</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_e887666d-8439-48f9-b3a5-eb2d7b0e49b6">
<qz-flipcard>
	<qz-front>straight ahead</qz-front>
	<qz-back>rett fram</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_0dfcf345-8eb5-41b1-9d7b-e4d54d12139d">
<qz-flipcard>
	<qz-front>a dog</qz-front>
	<qz-back>en hund</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_b66e843d-0a1b-4e29-bfa1-4e64c7ab93d1">
<qz-flipcard>
	<qz-front>a sun</qz-front>
	<qz-back>en sol</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_8a72efa5-6a5b-4581-b503-3dcc17868ebe">
<qz-flipcard>
	<qz-front>a wife/the wife</qz-front>
	<qz-back>en kone/kona</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_f4c8a862-3f03-4d84-8478-9301814d89cb">
<qz-flipcard>
	<qz-front>a child</qz-front>
	<qz-back>et barn</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_3a9e6983-3674-4b3f-b875-3a414953e138">
<qz-flipcard>
	<qz-front>a street</qz-front>
	<qz-back>en gate</qz-back>
</qz-flipcard>
</qz-practice>

<qz-practice qz-level-id="vocab_english2norwegian_469e78d2-a9ac-4ab5-b460-c21c2bb830b2">
<qz-flipcard>
	<qz-front>to hear</qz-front>
	<qz-back>å høre</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_833504cc-0fa3-47c6-8f4f-09487cfd747f">
<qz-flipcard>
	<qz-front>to know (facts)</qz-front>
	<qz-back>å vite</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_0b503118-2e55-4a2f-a4ab-0a65217b41b4">
<qz-flipcard>
	<qz-front>to know (person/place)</qz-front>
	<qz-back>å kjenne</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_4c66fd6c-cee7-41c4-8c8a-1abe06f4b281">
<qz-flipcard>
	<qz-front>a bathroom/a toilet</qz-front>
	<qz-back>et toalett</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_87aeebeb-66e5-465c-aba4-48b1ef5391c5">
<qz-flipcard>
	<qz-front>to understand</qz-front>
	<qz-back>å forstå</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_cc7bbcbb-91ed-47a5-ab03-1f09514d48a0">
<qz-flipcard>
	<qz-front>a city/town</qz-front>
	<qz-back>en by</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_da73b358-f1bb-4372-8f71-2a776208bb3f">
<qz-flipcard>
	<qz-front>a building</qz-front>
	<qz-back>en bygg</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_7de728eb-5818-47a6-8f17-d212a20134be">
<qz-flipcard>
	<qz-front>many</qz-front>
	<qz-back>mange</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_66d7d5c8-6bf8-419f-a931-39fe56fe9b73">
<qz-flipcard>
	<qz-front>a lot/much</qz-front>
	<qz-back>mye</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_5dcccbdc-5117-44c3-8080-3521ede51b86">
<qz-flipcard>
	<qz-front>sometimes</qz-front>
	<qz-back>noen ganger/av og til</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_1124ea0b-0565-44a0-adec-0be8d379e8c2">
<qz-flipcard>
	<qz-front>because(ger. weil)</qz-front>
	<qz-back>fordi</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_e75040df-0d81-4786-afff-fac3c3aaeb9e">
<qz-flipcard>
	<qz-front>swedish</qz-front>
	<qz-back>svensk</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_38b95e35-4bad-4e21-a9e9-6079a2053c0a">
<qz-flipcard>
	<qz-front>in the morning</qz-front>
	<qz-back>om morgenen</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_1d7579ce-d61b-4fd1-a9bc-2df0a6ab6d58">
<qz-flipcard>
	<qz-front>a friend</qz-front>
	<qz-back>en venn</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_db3080f3-76d5-40c5-b040-ae2c4987b65c">
<qz-flipcard>
	<qz-front>with</qz-front>
	<qz-back>med</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_fc23afe5-e4d3-4282-895b-bde407bc6ceb">
<qz-flipcard>
	<qz-front>but</qz-front>
	<qz-back>men</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_0f36e29d-c8cc-4013-b487-ea4b31a68f92">
<qz-flipcard>
	<qz-front>a evening</qz-front>
	<qz-back>en kveld</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_645ae33c-0454-45ad-80ed-7a3d7e5bd43c">
<qz-flipcard>
	<qz-front>yesterday</qz-front>
	<qz-back>i går</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_2823c069-b386-41a9-885f-4a994a0b2f60">
<qz-flipcard>
	<qz-front>worked (past tense)</qz-front>
	<qz-back>jobbet</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_df21300c-4999-42fc-836a-93a30d9a6556">
<qz-flipcard>
	<qz-front>very</qz-front>
	<qz-back>veldig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_469e78d2-a9ac-4ab5-b460-c21c2bb830b2">
<qz-flipcard>
	<qz-front>å høre</qz-front>
	<qz-back>to hear</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_833504cc-0fa3-47c6-8f4f-09487cfd747f">
<qz-flipcard>
	<qz-front>å vite</qz-front>
	<qz-back>to know (facts)</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_0b503118-2e55-4a2f-a4ab-0a65217b41b4">
<qz-flipcard>
	<qz-front>å kjenne</qz-front>
	<qz-back>to know (person/place)</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_4c66fd6c-cee7-41c4-8c8a-1abe06f4b281">
<qz-flipcard>
	<qz-front>et toalett</qz-front>
	<qz-back>a bathroom/a toilet</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_87aeebeb-66e5-465c-aba4-48b1ef5391c5">
<qz-flipcard>
	<qz-front>å forstå</qz-front>
	<qz-back>to understand</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_cc7bbcbb-91ed-47a5-ab03-1f09514d48a0">
<qz-flipcard>
	<qz-front>en by</qz-front>
	<qz-back>a city/town</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_da73b358-f1bb-4372-8f71-2a776208bb3f">
<qz-flipcard>
	<qz-front>en bygg</qz-front>
	<qz-back>a building</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_7de728eb-5818-47a6-8f17-d212a20134be">
<qz-flipcard>
	<qz-front>mange</qz-front>
	<qz-back>many</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_66d7d5c8-6bf8-419f-a931-39fe56fe9b73">
<qz-flipcard>
	<qz-front>mye</qz-front>
	<qz-back>a lot/much</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_5dcccbdc-5117-44c3-8080-3521ede51b86">
<qz-flipcard>
	<qz-front>noen ganger/av og til</qz-front>
	<qz-back>sometimes</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_1124ea0b-0565-44a0-adec-0be8d379e8c2">
<qz-flipcard>
	<qz-front>fordi</qz-front>
	<qz-back>because(ger. weil)</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_e75040df-0d81-4786-afff-fac3c3aaeb9e">
<qz-flipcard>
	<qz-front>svensk</qz-front>
	<qz-back>swedish</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_38b95e35-4bad-4e21-a9e9-6079a2053c0a">
<qz-flipcard>
	<qz-front>om morgenen</qz-front>
	<qz-back>in the morning</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_1d7579ce-d61b-4fd1-a9bc-2df0a6ab6d58">
<qz-flipcard>
	<qz-front>en venn</qz-front>
	<qz-back>a friend</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_db3080f3-76d5-40c5-b040-ae2c4987b65c">
<qz-flipcard>
	<qz-front>med</qz-front>
	<qz-back>with</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_fc23afe5-e4d3-4282-895b-bde407bc6ceb">
<qz-flipcard>
	<qz-front>men</qz-front>
	<qz-back>but</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_0f36e29d-c8cc-4013-b487-ea4b31a68f92">
<qz-flipcard>
	<qz-front>en kveld</qz-front>
	<qz-back>a evening</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_645ae33c-0454-45ad-80ed-7a3d7e5bd43c">
<qz-flipcard>
	<qz-front>i går</qz-front>
	<qz-back>yesterday</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_2823c069-b386-41a9-885f-4a994a0b2f60">
<qz-flipcard>
	<qz-front>jobbet</qz-front>
	<qz-back>worked (past tense)</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_df21300c-4999-42fc-836a-93a30d9a6556">
<qz-flipcard>
	<qz-front>veldig</qz-front>
	<qz-back>very</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_9ebc6fe1-c012-4f2c-b514-918620d04e34">
<qz-flipcard>
	<qz-front>happy</qz-front>
	<qz-back>glad</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_a95809de-9e69-4d72-bd6d-265ff6fd54f7">
<qz-flipcard>
	<qz-front>sad</qz-front>
	<qz-back>trist</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_d9d5122d-535c-4996-b39c-7fa9941548da">
<qz-flipcard>
	<qz-front>angry</qz-front>
	<qz-back>sint</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_a93fc29c-f0e2-4d4a-a131-f53d1513d020">
<qz-flipcard>
	<qz-front>nervous</qz-front>
	<qz-back>nervøs</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_db6f55ba-d653-4641-a769-80edff05111a">
<qz-flipcard>
	<qz-front>surprised</qz-front>
	<qz-back>overrasket</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_a7bd05e5-6d35-419f-8948-1396f689f95a">
<qz-flipcard>
	<qz-front>proud</qz-front>
	<qz-back>stolt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_8af45299-c816-4165-96f1-2317289a0e31">
<qz-flipcard>
	<qz-front>disappointed</qz-front>
	<qz-back>skuffet</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_0b455d7d-a10e-43d2-8070-324e862dfb75">
<qz-flipcard>
	<qz-front>to think (opinion)</qz-front>
	<qz-back>å mene</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_860c249c-c862-4f8e-85ee-a60c7f356ed1">
<qz-flipcard>
	<qz-front>to think/find</qz-front>
	<qz-back>å synes</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_400cdcc9-1de4-47fb-aea3-82f26696be69">
<qz-flipcard>
	<qz-front>interesting</qz-front>
	<qz-back>interessant</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_b1e6b7f5-4827-4faa-81ae-2ccfbaeec51b">
<qz-flipcard>
	<qz-front>boring</qz-front>
	<qz-back>kjedelig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_b219d424-f22b-4752-b202-3928b2f8c24e">
<qz-flipcard>
	<qz-front>important</qz-front>
	<qz-back>viktig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_8cde1515-c333-4b04-9d10-e7e00d8ecc99">
<qz-flipcard>
	<qz-front>recently</qz-front>
	<qz-back>nylig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_2619d64f-9965-4706-a660-8b11b365899a">
<qz-flipcard>
	<qz-front>soon</qz-front>
	<qz-back>snart</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_796bf1a8-5628-4bfc-8fba-51a8f6cc7e7d">
<qz-flipcard>
	<qz-front>still</qz-front>
	<qz-back>fortsatt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_a38934aa-8dd0-4064-8e97-9d9b6b2e6270">
<qz-flipcard>
	<qz-front>suddenly</qz-front>
	<qz-back>plutselig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_91b1d7b6-b5fe-470f-b506-ccd39f5a9ce6">
<qz-flipcard>
	<qz-front>a forest</qz-front>
	<qz-back>en skog</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_a2f31c05-d421-4b2b-80d0-9282a43249da">
<qz-flipcard>
	<qz-front>a mountain</qz-front>
	<qz-back>et fjell</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_2b331fcb-f347-4d11-a43a-d5264903804f">
<qz-flipcard>
	<qz-front>a lake</qz-front>
	<qz-back>en innsjø</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_99f99a3f-d6c1-4046-b1a5-cd3aa124152c">
<qz-flipcard>
	<qz-front>a river</qz-front>
	<qz-back>en elv</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_5f2353be-8089-43f9-b21c-e103df988bf6">
<qz-flipcard>
	<qz-front>a sea/ocean</qz-front>
	<qz-back>et hav</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_d805f8f3-8b92-4f13-88ed-ae358793785a">
<qz-flipcard>
	<qz-front>a lake/water</qz-front>
	<qz-back>et vann</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_e5e03407-eced-4ca3-b3eb-e9cd23438615">
<qz-flipcard>
	<qz-front>a fjord</qz-front>
	<qz-back>en fjord</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_11989224-818f-4b94-8e44-af47b33caff7">
<qz-flipcard>
	<qz-front>a stream/brook</qz-front>
	<qz-back>en bekk</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_c9d000c5-08a7-4f98-b2b3-50b681f21a9f">
<qz-flipcard>
	<qz-front>an island</qz-front>
	<qz-back>en øy</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_c683c61d-97ee-4d24-92c4-53865d7dcc26">
<qz-flipcard>
	<qz-front>a valley</qz-front>
	<qz-back>en dal</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_ebf02747-e089-4bc1-a6ea-66f46d076268">
<qz-flipcard>
	<qz-front>a native language</qz-front>
	<qz-back>et morsmål</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_7804ff2a-1cb9-4d2c-993c-c3553f825c21">
<qz-flipcard>
	<qz-front>a dialect</qz-front>
	<qz-back>en dialekt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_33686570-ce96-4198-8bcb-97214d30f72a">
<qz-flipcard>
	<qz-front>a pronunctiaton</qz-front>
	<qz-back>en uttale</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_f87b6588-ffe5-4b9d-b438-93369aa4659d">
<qz-flipcard>
	<qz-front>a vocabulary</qz-front>
	<qz-back>et ordforråd</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_b26ba0f6-9a69-4001-8433-f5042303b19d">
<qz-flipcard>
	<qz-front>a grammar</qz-front>
	<qz-back>en grammatikk</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_d8d97954-fb22-490c-bbe7-6290bae99fec">
<qz-flipcard>
	<qz-front>a method</qz-front>
	<qz-back>en metode</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_96c7b0cd-a295-4820-b075-b7146dc88872">
<qz-flipcard>
	<qz-front>a theory</qz-front>
	<qz-back>en teori</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_362dee4f-8a44-4c5f-bdbc-6674605c7e92">
<qz-flipcard>
	<qz-front>an analysis</qz-front>
	<qz-back>en analyse</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norsk_5b99fa61-e508-4461-9f02-1ea1fac98f0b">
<qz-flipcard>
	<qz-front>to expand</qz-front>
	<qz-back>å utvide</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_9ebc6fe1-c012-4f2c-b514-918620d04e34">
<qz-flipcard>
	<qz-front>glad</qz-front>
	<qz-back>happy</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_a95809de-9e69-4d72-bd6d-265ff6fd54f7">
<qz-flipcard>
	<qz-front>trist</qz-front>
	<qz-back>sad</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_d9d5122d-535c-4996-b39c-7fa9941548da">
<qz-flipcard>
	<qz-front>sint</qz-front>
	<qz-back>angry</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_a93fc29c-f0e2-4d4a-a131-f53d1513d020">
<qz-flipcard>
	<qz-front>nervøs</qz-front>
	<qz-back>nervous</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_db6f55ba-d653-4641-a769-80edff05111a">
<qz-flipcard>
	<qz-front>overrasket</qz-front>
	<qz-back>surprised</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_a7bd05e5-6d35-419f-8948-1396f689f95a">
<qz-flipcard>
	<qz-front>stolt</qz-front>
	<qz-back>proud</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_8af45299-c816-4165-96f1-2317289a0e31">
<qz-flipcard>
	<qz-front>skuffet</qz-front>
	<qz-back>disappointed</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_0b455d7d-a10e-43d2-8070-324e862dfb75">
<qz-flipcard>
	<qz-front>å mene</qz-front>
	<qz-back>to think (opinion)</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_860c249c-c862-4f8e-85ee-a60c7f356ed1">
<qz-flipcard>
	<qz-front>å synes</qz-front>
	<qz-back>to think/find</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_400cdcc9-1de4-47fb-aea3-82f26696be69">
<qz-flipcard>
	<qz-front>interessant</qz-front>
	<qz-back>interesting</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_b1e6b7f5-4827-4faa-81ae-2ccfbaeec51b">
<qz-flipcard>
	<qz-front>kjedelig</qz-front>
	<qz-back>boring</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_b219d424-f22b-4752-b202-3928b2f8c24e">
<qz-flipcard>
	<qz-front>viktig</qz-front>
	<qz-back>important</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_8cde1515-c333-4b04-9d10-e7e00d8ecc99">
<qz-flipcard>
	<qz-front>nylig</qz-front>
	<qz-back>recently</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_2619d64f-9965-4706-a660-8b11b365899a">
<qz-flipcard>
	<qz-front>snart</qz-front>
	<qz-back>soon</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_796bf1a8-5628-4bfc-8fba-51a8f6cc7e7d">
<qz-flipcard>
	<qz-front>fortsatt</qz-front>
	<qz-back>still</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_a38934aa-8dd0-4064-8e97-9d9b6b2e6270">
<qz-flipcard>
	<qz-front>plutselig</qz-front>
	<qz-back>suddenly</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_91b1d7b6-b5fe-470f-b506-ccd39f5a9ce6">
<qz-flipcard>
	<qz-front>en skog</qz-front>
	<qz-back>a forest</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_a2f31c05-d421-4b2b-80d0-9282a43249da">
<qz-flipcard>
	<qz-front>et fjell</qz-front>
	<qz-back>a mountain</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_2b331fcb-f347-4d11-a43a-d5264903804f">
<qz-flipcard>
	<qz-front>en innsjø</qz-front>
	<qz-back>a lake</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_99f99a3f-d6c1-4046-b1a5-cd3aa124152c">
<qz-flipcard>
	<qz-front>en elv</qz-front>
	<qz-back>a river</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_5f2353be-8089-43f9-b21c-e103df988bf6">
<qz-flipcard>
	<qz-front>et hav</qz-front>
	<qz-back>a sea/ocean</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_d805f8f3-8b92-4f13-88ed-ae358793785a">
<qz-flipcard>
	<qz-front>et vann</qz-front>
	<qz-back>a lake/water</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_e5e03407-eced-4ca3-b3eb-e9cd23438615">
<qz-flipcard>
	<qz-front>en fjord</qz-front>
	<qz-back>a fjord</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_11989224-818f-4b94-8e44-af47b33caff7">
<qz-flipcard>
	<qz-front>en bekk</qz-front>
	<qz-back>a stream/brook</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_c9d000c5-08a7-4f98-b2b3-50b681f21a9f">
<qz-flipcard>
	<qz-front>en øy</qz-front>
	<qz-back>an island</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_c683c61d-97ee-4d24-92c4-53865d7dcc26">
<qz-flipcard>
	<qz-front>en dal</qz-front>
	<qz-back>a valley</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_ebf02747-e089-4bc1-a6ea-66f46d076268">
<qz-flipcard>
	<qz-front>et morsmål</qz-front>
	<qz-back>a native language</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_7804ff2a-1cb9-4d2c-993c-c3553f825c21">
<qz-flipcard>
	<qz-front>en dialekt</qz-front>
	<qz-back>a dialect</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_33686570-ce96-4198-8bcb-97214d30f72a">
<qz-flipcard>
	<qz-front>en uttale</qz-front>
	<qz-back>a pronunctiaton</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_f87b6588-ffe5-4b9d-b438-93369aa4659d">
<qz-flipcard>
	<qz-front>et ordforråd</qz-front>
	<qz-back>a vocabulary</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_b26ba0f6-9a69-4001-8433-f5042303b19d">
<qz-flipcard>
	<qz-front>en grammatikk</qz-front>
	<qz-back>a grammar</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_d8d97954-fb22-490c-bbe7-6290bae99fec">
<qz-flipcard>
	<qz-front>en metode</qz-front>
	<qz-back>a method</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_96c7b0cd-a295-4820-b075-b7146dc88872">
<qz-flipcard>
	<qz-front>en teori</qz-front>
	<qz-back>a theory</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_362dee4f-8a44-4c5f-bdbc-6674605c7e92">
<qz-flipcard>
	<qz-front>en analyse</qz-front>
	<qz-back>an analysis</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norsk2english_5b99fa61-e508-4461-9f02-1ea1fac98f0b">
<qz-flipcard>
	<qz-front>å utvide</qz-front>
	<qz-back>to expand</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_5f47f956-23e0-470d-b1b1-6ba189ef1724">
<qz-flipcard>
	<qz-front>an axe</qz-front>
	<qz-back>en øks</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_393d0dea-bcc5-417d-9f80-ff6966445325">
<qz-flipcard>
	<qz-front>every single person</qz-front>
	<qz-back>hvert enkelt manneskin</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_a47bb8ba-14b4-47ca-a8ad-7488ee2d2745">
<qz-flipcard>
	<qz-front>single</qz-front>
	<qz-back>enkelt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_cadacae9-f7fa-41eb-b982-dee4f4017f28">
<qz-flipcard>
	<qz-front>a rib/lamelle, ribs/lamellen</qz-front>
	<qz-back>en ribbe, ripper</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_9f146eb8-288b-4e62-91cb-26ae915de84d">
<qz-flipcard>
	<qz-front>safe/certain</qz-front>
	<qz-back>sikre</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_b0c4e7b0-c56d-4988-b242-5755cdf96c19">
<qz-flipcard>
	<qz-front>edible</qz-front>
	<qz-back>spiselig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_a350b988-98a9-4790-98bc-e130493b5fda">
<qz-flipcard>
	<qz-front>a mushroom</qz-front>
	<qz-back>en sopp</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_de296f65-67f6-400b-bda9-d769c00aa945">
<qz-flipcard>
	<qz-front>to wilt</qz-front>
	<qz-back>å visne</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_6932391b-3c70-47bc-b0d7-6e8aadf32fdc">
<qz-flipcard>
	<qz-front>repeated</qz-front>
	<qz-back>gjentatt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_025d0f1c-5893-4900-b350-3341cbf9834a">
<qz-flipcard>
	<qz-front>an hour</qz-front>
	<qz-back>en time</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_b855615e-b311-4468-9e3a-55d373572c58">
<qz-flipcard>
	<qz-front>to rub in</qz-front>
	<qz-back>å gni ... inn</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_83490653-47cb-45f6-a3e8-aa9fbc28f2d6">
<qz-flipcard>
	<qz-front>application of (makeup/cream/medication)</qz-front>
	<qz-back>påføring av</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_40f443d4-4585-4eed-a047-f7f50dd71b10">
<qz-flipcard>
	<qz-front>a porridge</qz-front>
	<qz-back>en grøt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_2bc92eba-6be8-4e4e-befd-5341aa096555">
<qz-flipcard>
	<qz-front>thick</qz-front>
	<qz-back>tykk/tykt/tykke</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_4af9d865-f49b-4864-9d39-875c959b7ade">
<qz-flipcard>
	<qz-front>to dry</qz-front>
	<qz-back>å tørke</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_04e2937f-26c8-46cb-8386-80f8acff0575">
<qz-flipcard>
	<qz-front>actually/really</qz-front>
	<qz-back>egentlig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_a8eb2b70-631e-4804-ace8-97af84435b10">
<qz-flipcard>
	<qz-front>unfortunately</qz-front>
	<qz-back>dessverre</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_707c6b24-3ee3-4f5a-a6f4-f2bd1117c2b4">
<qz-flipcard>
	<qz-front>fortunately</qz-front>
	<qz-back>heldigvis</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_61168b67-29eb-4963-bf96-4f8cd35b5981">
<qz-flipcard>
	<qz-front>maybe</qz-front>
	<qz-back>kanskje</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_9a8d5eeb-eca4-4d7b-91c1-390fd4826e1d">
<qz-flipcard>
	<qz-front>of course</qz-front>
	<qz-back>selvfølgelig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_ea265978-0874-45ec-ac7f-5aa4d4c5ac02">
<qz-flipcard>
	<qz-front>a basket</qz-front>
	<qz-back>et kurv</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_d6624ab4-43ec-4443-84c3-e6e51df0b94f">
<qz-flipcard>
	<qz-front>a leaf</qz-front>
	<qz-back>et blad</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_062e9ca9-7534-42e6-993c-b95bd94478a9">
<qz-flipcard>
	<qz-front>a branch</qz-front>
	<qz-back>en gren</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_c32c70a3-3b62-4bf6-95d5-e6ae74524ff5">
<qz-flipcard>
	<qz-front>a root, roots</qz-front>
	<qz-back>en rot/røtter</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_c595a6c9-f82d-4c12-97fa-499ca3d22c0d">
<qz-flipcard>
	<qz-front>a rock</qz-front>
	<qz-back>en stein</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_44286feb-df48-461d-be87-987708c7551e">
<qz-flipcard>
	<qz-front>a bog/marsh</qz-front>
	<qz-back>en myr</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_f99405d0-85a7-46ff-a324-4b7090e3622b">
<qz-flipcard>
	<qz-front>a hunter</qz-front>
	<qz-back>en jeger</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_d60480b8-64d7-4d00-9165-4ef79e511e7d">
<qz-flipcard>
	<qz-front>a hat/cap</qz-front>
	<qz-back>en hatt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_93d16689-29e5-433f-a1e2-a151a113134f">
<qz-flipcard>
	<qz-front>a stemp</qz-front>
	<qz-back>en stilk</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_6739d696-b2d5-4986-8c5a-f51aa4c206d4">
<qz-flipcard>
	<qz-front>to grow</qz-front>
	<qz-back>å vokse</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_4bdfcbad-3594-44d3-975f-4828b81c17f5">
<qz-flipcard>
	<qz-front>to find</qz-front>
	<qz-back>å finne</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_dd095dec-847a-4359-a1c1-9b838e250ecf">
<qz-flipcard>
	<qz-front>to exist</qz-front>
	<qz-back>å finnes</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_051cb98e-f63e-472b-b8b0-e03a030ccbcb">
<qz-flipcard>
	<qz-front>to pick/gather</qz-front>
	<qz-back>å plukke</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_bb6043ff-2c98-49a6-a1f9-17b71d63f904">
<qz-flipcard>
	<qz-front>rare</qz-front>
	<qz-back>sjelden</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_5e6db48c-3d9a-4f91-9729-d75603aea985">
<qz-flipcard>
	<qz-front>common</qz-front>
	<qz-back>vanlig</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_26fb1bab-4994-4839-aad1-cf061a800530">
<qz-flipcard>
	<qz-front>rain</qz-front>
	<qz-back>regn</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_bd636825-f9b1-4be6-9c40-8458fc4b768b">
<qz-flipcard>
	<qz-front>fog</qz-front>
	<qz-back>tåke</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_a81e4094-a26b-4e7d-913d-fb1ada203e61">
<qz-flipcard>
	<qz-front>wind</qz-front>
	<qz-back>vind</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_84cbb6c5-69a9-40c0-98a6-5e26e2f13ac3">
<qz-flipcard>
	<qz-front>sunshine</qz-front>
	<qz-back>solskin</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_615d46ec-a890-400f-a4ac-ae05ea9ff3ea">
<qz-flipcard>
	<qz-front>today</qz-front>
	<qz-back>i dag</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_english2norwegian_54b59f5f-0895-413d-bfb3-faf317e63ef8">
<qz-flipcard>
	<qz-front>tomorrow</qz-front>
	<qz-back>i morgen</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_5f47f956-23e0-470d-b1b1-6ba189ef1724">
<qz-flipcard>
	<qz-front>en øks</qz-front>
	<qz-back>an axe</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_393d0dea-bcc5-417d-9f80-ff6966445325">
<qz-flipcard>
	<qz-front>hvert enkelt manneskin</qz-front>
	<qz-back>every single person</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_a47bb8ba-14b4-47ca-a8ad-7488ee2d2745">
<qz-flipcard>
	<qz-front>enkelt</qz-front>
	<qz-back>single</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_cadacae9-f7fa-41eb-b982-dee4f4017f28">
<qz-flipcard>
	<qz-front>en ribbe, ripper</qz-front>
	<qz-back>a rib/lamelle, ribs/lamellen</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_9f146eb8-288b-4e62-91cb-26ae915de84d">
<qz-flipcard>
	<qz-front>sikre</qz-front>
	<qz-back>safe/certain</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_b0c4e7b0-c56d-4988-b242-5755cdf96c19">
<qz-flipcard>
	<qz-front>spiselig</qz-front>
	<qz-back>edible</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_a350b988-98a9-4790-98bc-e130493b5fda">
<qz-flipcard>
	<qz-front>en sopp</qz-front>
	<qz-back>a mushroom</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_de296f65-67f6-400b-bda9-d769c00aa945">
<qz-flipcard>
	<qz-front>å visne</qz-front>
	<qz-back>to wilt</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_6932391b-3c70-47bc-b0d7-6e8aadf32fdc">
<qz-flipcard>
	<qz-front>gjentatt</qz-front>
	<qz-back>repeated</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_025d0f1c-5893-4900-b350-3341cbf9834a">
<qz-flipcard>
	<qz-front>en time</qz-front>
	<qz-back>an hour</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_b855615e-b311-4468-9e3a-55d373572c58">
<qz-flipcard>
	<qz-front>å gni ... inn</qz-front>
	<qz-back>to rub in</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_83490653-47cb-45f6-a3e8-aa9fbc28f2d6">
<qz-flipcard>
	<qz-front>påføring av</qz-front>
	<qz-back>application of (makeup/cream/medication)</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_40f443d4-4585-4eed-a047-f7f50dd71b10">
<qz-flipcard>
	<qz-front>en grøt</qz-front>
	<qz-back>a porridge</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_2bc92eba-6be8-4e4e-befd-5341aa096555">
<qz-flipcard>
	<qz-front>tykk/tykt/tykke</qz-front>
	<qz-back>thick</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_4af9d865-f49b-4864-9d39-875c959b7ade">
<qz-flipcard>
	<qz-front>å tørke</qz-front>
	<qz-back>to dry</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_04e2937f-26c8-46cb-8386-80f8acff0575">
<qz-flipcard>
	<qz-front>egentlig</qz-front>
	<qz-back>actually/really</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_a8eb2b70-631e-4804-ace8-97af84435b10">
<qz-flipcard>
	<qz-front>dessverre</qz-front>
	<qz-back>unfortunately</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_707c6b24-3ee3-4f5a-a6f4-f2bd1117c2b4">
<qz-flipcard>
	<qz-front>heldigvis</qz-front>
	<qz-back>fortunately</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_61168b67-29eb-4963-bf96-4f8cd35b5981">
<qz-flipcard>
	<qz-front>kanskje</qz-front>
	<qz-back>maybe</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_9a8d5eeb-eca4-4d7b-91c1-390fd4826e1d">
<qz-flipcard>
	<qz-front>selvfølgelig</qz-front>
	<qz-back>of course</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_ea265978-0874-45ec-ac7f-5aa4d4c5ac02">
<qz-flipcard>
	<qz-front>et kurv</qz-front>
	<qz-back>a basket</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_d6624ab4-43ec-4443-84c3-e6e51df0b94f">
<qz-flipcard>
	<qz-front>et blad</qz-front>
	<qz-back>a leaf</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_062e9ca9-7534-42e6-993c-b95bd94478a9">
<qz-flipcard>
	<qz-front>en gren</qz-front>
	<qz-back>a branch</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_c32c70a3-3b62-4bf6-95d5-e6ae74524ff5">
<qz-flipcard>
	<qz-front>en rot/røtter</qz-front>
	<qz-back>a root, roots</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_c595a6c9-f82d-4c12-97fa-499ca3d22c0d">
<qz-flipcard>
	<qz-front>en stein</qz-front>
	<qz-back>a rock</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_44286feb-df48-461d-be87-987708c7551e">
<qz-flipcard>
	<qz-front>en myr</qz-front>
	<qz-back>a bog/marsh</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_f99405d0-85a7-46ff-a324-4b7090e3622b">
<qz-flipcard>
	<qz-front>en jeger</qz-front>
	<qz-back>a hunter</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_d60480b8-64d7-4d00-9165-4ef79e511e7d">
<qz-flipcard>
	<qz-front>en hatt</qz-front>
	<qz-back>a hat/cap</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_93d16689-29e5-433f-a1e2-a151a113134f">
<qz-flipcard>
	<qz-front>en stilk</qz-front>
	<qz-back>a stemp</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_6739d696-b2d5-4986-8c5a-f51aa4c206d4">
<qz-flipcard>
	<qz-front>å vokse</qz-front>
	<qz-back>to grow</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_4bdfcbad-3594-44d3-975f-4828b81c17f5">
<qz-flipcard>
	<qz-front>å finne</qz-front>
	<qz-back>to find</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_dd095dec-847a-4359-a1c1-9b838e250ecf">
<qz-flipcard>
	<qz-front>å finnes</qz-front>
	<qz-back>to exist</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_051cb98e-f63e-472b-b8b0-e03a030ccbcb">
<qz-flipcard>
	<qz-front>å plukke</qz-front>
	<qz-back>to pick/gather</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_bb6043ff-2c98-49a6-a1f9-17b71d63f904">
<qz-flipcard>
	<qz-front>sjelden</qz-front>
	<qz-back>rare</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_5e6db48c-3d9a-4f91-9729-d75603aea985">
<qz-flipcard>
	<qz-front>vanlig</qz-front>
	<qz-back>common</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_26fb1bab-4994-4839-aad1-cf061a800530">
<qz-flipcard>
	<qz-front>regn</qz-front>
	<qz-back>rain</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_bd636825-f9b1-4be6-9c40-8458fc4b768b">
<qz-flipcard>
	<qz-front>tåke</qz-front>
	<qz-back>fog</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_a81e4094-a26b-4e7d-913d-fb1ada203e61">
<qz-flipcard>
	<qz-front>vind</qz-front>
	<qz-back>wind</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_84cbb6c5-69a9-40c0-98a6-5e26e2f13ac3">
<qz-flipcard>
	<qz-front>solskin</qz-front>
	<qz-back>sunshine</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_615d46ec-a890-400f-a4ac-ae05ea9ff3ea">
<qz-flipcard>
	<qz-front>i dag</qz-front>
	<qz-back>today</qz-back>
</qz-flipcard>
</qz-practice>
<qz-practice qz-level-id="vocab_norwegian2english_54b59f5f-0895-413d-bfb3-faf317e63ef8">
<qz-flipcard>
	<qz-front>i morgen</qz-front>
	<qz-back>tomorrow</qz-back>
</qz-flipcard>
</qz-practice>


</qz-quiz>
