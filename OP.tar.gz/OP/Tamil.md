<qz-practice qz-level-id="tamil_vocal_a">
<qz-flipcard>
    <qz-front>a - short, a - long, a - short comb, a - long comb</qz-front>
    <qz-back>
        அ ஆ -  ா
	</qz-back>
</qz-flipcard>
</qz-practice>

<qz-practice qz-level-id="tamil_vocal_e">
<qz-flipcard>
    <qz-front>e - short, e - long, e - short comb, e - long comb</qz-front>
    <qz-back>
        எ ஏ  ெ  ே
	</qz-back>
</qz-flipcard>
</qz-practice>

<qz-practice qz-level-id="tamil_vocal_i">
<qz-flipcard>
    <qz-front>i - short, i - long, i - short comb, i - long comb</qz-front>
    <qz-back>
        இ ஈ  ி  ீ 
	</qz-back>
</qz-flipcard>
</qz-practice>

<qz-practice qz-level-id="tamil_vocal_o">
<qz-flipcard>
    <qz-front>o - short, o - long, o - short comb, o - long comb</qz-front>
    <qz-back>
        ஒ ஓ  ொ  ோ
	</qz-back>
</qz-flipcard>
</qz-practice>

<qz-practice qz-level-id="tamil_vocal_u">
<qz-flipcard>
    <qz-front>u - short, u - long, u - short comb, u - long comb</qz-front>
    <qz-back>
        உ ஊ  ு  ூ
	</qz-back>
</qz-flipcard>
</qz-practice>

<qz-practice qz-level-id="tamil_word_shrimp">
<qz-flipcard>
    <qz-front>shrimp</qz-front>
    <qz-back>இறால்</qz-back>
</qz-flipcard>
</qz-practice>

<qz-category>
    <qz-question>Match each Tamil vowel to its English transliteration.</qz-question>
    <!-- Each qz-category is a "drop target" (category) -->
    <!-- The pick="1" means: draw 1 random Tamil letter from this category each round -->
    <!-- qz-title is JUST the category name — NO answer given away! -->
    <qz-category pick="1">
        <qz-title>a</qz-title>
        <qz-answer>அ</qz-answer>
    </qz-category>
    <qz-category pick="1">
        <qz-title>aa</qz-title>
        <qz-answer>ஆ</qz-answer>
    </qz-category>
    <qz-category pick="1">
        <qz-title>i</qz-title>
        <qz-answer>இ</qz-answer>
    </qz-category>
    <qz-category pick="1">
        <qz-title>ii</qz-title>
        <qz-answer>ஈ</qz-answer>
    </qz-category>
    <qz-category pick="1">
        <qz-title>u</qz-title>
        <qz-answer>உ</qz-answer>
    </qz-category>
    <qz-category pick="1">
        <qz-title>uu</qz-title>
        <qz-answer>ஊ</qz-answer>
    </qz-category>
    <qz-category pick="1">
        <qz-title>e</qz-title>
        <qz-answer>எ</qz-answer>
    </qz-category>
    <qz-category pick="1">
        <qz-title>ee</qz-title>
        <qz-answer>ஏ</qz-answer>
    </qz-category>
    <qz-category pick="1">
        <qz-title>ai</qz-title>
        <qz-answer>ஐ</qz-answer>
    </qz-category>
    <qz-category pick="1">
        <qz-title>o</qz-title>
        <qz-answer>ஒ</qz-answer>
    </qz-category>
    <qz-category pick="1">
        <qz-title>oo</qz-title>
        <qz-answer>ஓ</qz-answer>
    </qz-category>
    <qz-category pick="1">
        <qz-title>au</qz-title>
        <qz-answer>ஔ</qz-answer>
    </qz-category>
    <!-- Distractors — extra Tamil letters that don't belong to any category -->
    <!-- These get shuffled in as wrong options to make it challenging -->
    <qz-answer>க</qz-answer>
    <qz-answer>ங</qz-answer>
    <qz-answer>ச</qz-answer>
    <qz-answer>ஞ</qz-answer>
    <qz-answer>ட</qz-answer>
    <qz-answer>ண</qz-answer>
    <qz-answer>த</qz-answer>
    <qz-answer>ந</qz-answer>
    <qz-answer>ப</qz-answer>
    <qz-answer>ம</qz-answer>
    <qz-answer>ய</qz-answer>
    <qz-answer>ர</qz-answer>
    <qz-answer>ல</qz-answer>
    <qz-answer>வ</qz-answer>
    <qz-answer>ழ</qz-answer>
    <qz-answer>ள</qz-answer>
    <qz-answer>ன</qz-answer>
</qz-category>
